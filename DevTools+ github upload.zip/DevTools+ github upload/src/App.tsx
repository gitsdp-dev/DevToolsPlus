import { useState, useEffect, useMemo } from 'react';
import {
  Code2, Sparkles, Zap, Layers, Waves, Image, Tag, Bot, Map,
  Monitor, Eye, Keyboard, Database, ChevronRight, Menu, X,
  Terminal, Star, Search, Boxes, Clock
} from 'lucide-react';
import JsonFormatter from './tools/JsonFormatter';
import CodeBeautifier from './tools/CodeBeautifier';
import CssAnimationGenerator from './tools/CssAnimationGenerator';
import ShadowGenerator from './tools/ShadowGenerator';
import SvgWaveGenerator from './tools/SvgWaveGenerator';
import FaviconGenerator from './tools/FaviconGenerator';
import MetaTagGenerator from './tools/MetaTagGenerator';
import RobotsTxtGenerator from './tools/RobotsTxtGenerator';
import SitemapGenerator from './tools/SitemapGenerator';
import ResponsiveTester from './tools/ResponsiveTester';
import ColorContrastChecker from './tools/ColorContrastChecker';
import TypingSpeedTester from './tools/TypingSpeedTester';
import FakeDataGenerator from './tools/FakeDataGenerator';

interface Tool {
  id: string;
  label: string;
  icon: React.ReactNode;
  component: React.ComponentType;
  category: string;
  color: string;
  description: string;
  badge?: string;
  keywords?: string[];
}

const TOOLS: Tool[] = [
  {
    id: 'json', label: 'JSON Formatter', icon: <Code2 size={18} />, component: JsonFormatter,
    category: 'Formatters', color: '#00d4ff', description: 'Format, validate & minify JSON',
    badge: 'Popular', keywords: ['json', 'format', 'validate', 'minify', 'parse']
  },
  {
    id: 'beautifier', label: 'Code Beautifier', icon: <Sparkles size={18} />, component: CodeBeautifier,
    category: 'Formatters', color: '#a78bfa', description: 'Beautify HTML, CSS, JS, TypeScript',
    keywords: ['code', 'format', 'html', 'css', 'javascript', 'typescript', 'beautify']
  },
  {
    id: 'animation', label: 'CSS Animation', icon: <Zap size={18} />, component: CssAnimationGenerator,
    category: 'Generators', color: '#f59e0b', description: 'Generate custom CSS keyframe animations',
    badge: 'Live', keywords: ['css', 'animation', 'keyframe', 'transition', 'bounce', 'fade']
  },
  {
    id: 'shadow', label: 'Shadow Generator', icon: <Layers size={18} />, component: ShadowGenerator,
    category: 'Generators', color: '#ec4899', description: 'Visual box-shadow & text-shadow builder',
    keywords: ['shadow', 'box-shadow', 'css', 'design']
  },
  {
    id: 'wave', label: 'SVG Wave', icon: <Waves size={18} />, component: SvgWaveGenerator,
    category: 'Generators', color: '#06b6d4', description: 'Create SVG wave shapes & dividers',
    keywords: ['svg', 'wave', 'shape', 'divider', 'background']
  },
  {
    id: 'favicon', label: 'Favicon Generator', icon: <Image size={18} />, component: FaviconGenerator,
    category: 'Generators', color: '#10b981', description: 'Generate favicon icons for your website',
    keywords: ['favicon', 'icon', 'png', 'logo']
  },
  {
    id: 'meta', label: 'Meta Tag Generator', icon: <Tag size={18} />, component: MetaTagGenerator,
    category: 'SEO Tools', color: '#3b82f6', description: 'SEO, Open Graph & Twitter card tags',
    badge: 'SEO', keywords: ['meta', 'seo', 'open graph', 'twitter', 'html', 'tags']
  },
  {
    id: 'robots', label: 'Robots.txt', icon: <Bot size={18} />, component: RobotsTxtGenerator,
    category: 'SEO Tools', color: '#8b5cf6', description: 'Configure robot crawling rules',
    keywords: ['robots', 'crawl', 'seo', 'bot', 'sitemap']
  },
  {
    id: 'sitemap', label: 'Sitemap Generator', icon: <Map size={18} />, component: SitemapGenerator,
    category: 'SEO Tools', color: '#14b8a6', description: 'Build XML sitemaps for search engines',
    keywords: ['sitemap', 'xml', 'seo', 'url', 'search engine']
  },
  {
    id: 'responsive', label: 'Responsive Tester', icon: <Monitor size={18} />, component: ResponsiveTester,
    category: 'Testers', color: '#f97316', description: 'Preview sites on any device size',
    keywords: ['responsive', 'mobile', 'tablet', 'desktop', 'preview', 'device']
  },
  {
    id: 'contrast', label: 'Color Contrast', icon: <Eye size={18} />, component: ColorContrastChecker,
    category: 'Testers', color: '#a78bfa', description: 'WCAG accessibility contrast checker',
    badge: 'A11y', keywords: ['color', 'contrast', 'wcag', 'accessibility', 'a11y']
  },
  {
    id: 'typing', label: 'Typing Speed Test', icon: <Keyboard size={18} />, component: TypingSpeedTester,
    category: 'Testers', color: '#34d399', description: 'Measure your WPM typing speed',
    keywords: ['typing', 'speed', 'wpm', 'keyboard', 'words per minute']
  },
  {
    id: 'faker', label: 'Fake Data Generator', icon: <Database size={18} />, component: FakeDataGenerator,
    category: 'Generators', color: '#fb7185', description: 'Generate realistic test/mock data',
    badge: 'New', keywords: ['fake', 'data', 'mock', 'test', 'json', 'csv', 'sql', 'random']
  },
];

const CATEGORIES = Array.from(new Set(TOOLS.map(t => t.category)));

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'Formatters': <Code2 size={13} />,
  'Generators': <Boxes size={13} />,
  'SEO Tools': <Tag size={13} />,
  'Testers': <Monitor size={13} />,
};

function Sidebar({ activeTool, setActiveTool, isOpen, setIsOpen }: {
  activeTool: string;
  setActiveTool: (id: string) => void;
  isOpen: boolean;
  setIsOpen: (v: boolean) => void;
}) {
  const [search, setSearch] = useState('');

  const filteredTools = useMemo(() => {
    if (!search.trim()) return TOOLS;
    const q = search.toLowerCase();
    return TOOLS.filter(t =>
      t.label.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q) ||
      (t.keywords || []).some(k => k.includes(q))
    );
  }, [search]);

  const groupedTools = useMemo(() => {
    const groups: Record<string, Tool[]> = {};
    for (const cat of CATEGORIES) {
      const tools = filteredTools.filter(t => t.category === cat);
      if (tools.length > 0) groups[cat] = tools;
    }
    return groups;
  }, [filteredTools]);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/70 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside
        className={`fixed lg:static top-0 left-0 h-full z-50 lg:z-auto flex flex-col bg-[#0a0e1a] border-r border-[#1e2d50] transition-transform duration-300 w-72 ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1e2d50]">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #00d4ff, #7c3aed)' }}
          >
            <Terminal size={17} className="text-white" />
          </div>
          <div className="flex-1">
            <div className="font-black text-lg gradient-text leading-none">DevTools+</div>
            <div className="text-[10px] text-[#64748b] font-mono mt-0.5">13 tools · Free forever</div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="lg:hidden text-[#64748b] hover:text-white p-1 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search */}
        <div className="px-3 py-3 border-b border-[#1e2d50]">
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search tools..."
              className="input-field w-full pl-8 pr-3 py-2 rounded-xl text-sm"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-white"
              >
                <X size={12} />
              </button>
            )}
          </div>
        </div>

        {/* Tool list */}
        <nav className="flex-1 overflow-y-auto py-2 px-2">
          {/* Home button */}
          <button
            onClick={() => { setActiveTool('home'); setIsOpen(false); }}
            className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-2 text-left ${activeTool === 'home' ? 'active' : ''}`}
          >
            <span className="text-[#f59e0b]"><Star size={16} /></span>
            <span className={`text-sm font-semibold ${activeTool === 'home' ? 'text-white' : 'text-[#94a3b8]'}`}>Home</span>
          </button>

          {Object.entries(groupedTools).map(([cat, tools]) => (
            <div key={cat} className="mb-4">
              <div className="flex items-center gap-2 px-3 py-1 mb-1">
                <span className="text-[#64748b]">{CATEGORY_ICONS[cat]}</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#64748b] font-mono">{cat}</span>
                <span className="ml-auto text-[10px] text-[#3d526b] font-mono">{tools.length}</span>
              </div>
              {tools.map(tool => (
                <button
                  key={tool.id}
                  onClick={() => { setActiveTool(tool.id); setIsOpen(false); }}
                  className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-left ${activeTool === tool.id ? 'active' : ''}`}
                >
                  <span className="flex-shrink-0" style={{ color: tool.color }}>{tool.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium truncate ${activeTool === tool.id ? 'text-white' : 'text-[#94a3b8]'}`}>
                      {tool.label}
                    </div>
                  </div>
                  {tool.badge && (
                    <span
                      className="badge px-1.5 py-0.5 rounded-md text-[9px] flex-shrink-0"
                      style={{ background: tool.color + '22', color: tool.color, border: `1px solid ${tool.color}44` }}
                    >
                      {tool.badge}
                    </span>
                  )}
                  {activeTool === tool.id && (
                    <ChevronRight size={13} className="text-[#00d4ff] flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          ))}

          {Object.keys(groupedTools).length === 0 && (
            <div className="text-center py-8 text-[#64748b] text-sm">
              <Search size={24} className="mx-auto mb-2 opacity-50" />
              No tools found
            </div>
          )}
        </nav>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-[#1e2d50]">
          <div className="flex items-center gap-2 text-xs text-[#64748b]">
            <Star size={11} className="text-[#f59e0b]" />
            <span>Built for developers</span>
            <Clock size={11} className="ml-auto text-[#00d4ff]" />
            <span className="font-mono text-[10px]" id="clock"></span>
          </div>
        </div>
      </aside>
    </>
  );
}

function HomePage({ onSelectTool }: { onSelectTool: (id: string) => void }) {
  const stats = [
    { label: 'Tools', value: '13', icon: '🛠️', color: '#00d4ff' },
    { label: 'Export Formats', value: '10+', icon: '📦', color: '#7c3aed' },
    { label: 'Free Forever', value: '100%', icon: '✨', color: '#00ff88' },
    { label: 'No Signup', value: 'Zero', icon: '🔓', color: '#f59e0b' },
  ];

  return (
    <div className="animate-slide-in max-w-7xl mx-auto">
      {/* Hero */}
      <div className="text-center pt-10 pb-8 px-4">
        <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full border border-[#1e2d50] bg-[#0f1629] text-xs text-[#00d4ff] font-mono mb-6">
          <span className="w-2 h-2 rounded-full bg-[#00ff88]" style={{ animation: 'pulse 2s infinite' }} />
          <span>All tools · 100% free · No sign-up required</span>
        </div>

        <h1 className="text-5xl sm:text-6xl md:text-7xl font-black mb-5 leading-tight">
          <span className="gradient-text">DevTools+</span>
        </h1>

        <p className="text-[#64748b] text-base sm:text-lg max-w-2xl mx-auto mb-8 leading-relaxed">
          The ultimate developer toolkit — format, generate, analyze and test.
          Everything you need, beautifully crafted in one place.
        </p>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          {stats.map(s => (
            <div key={s.label} className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#1e2d50] bg-[#0f1629]">
              <span>{s.icon}</span>
              <span className="text-base font-black" style={{ color: s.color }}>{s.value}</span>
              <span className="text-sm text-[#64748b]">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tool grid by category */}
      {CATEGORIES.map(cat => (
        <div key={cat} className="mb-10">
          <div className="flex items-center gap-3 mb-4 px-1">
            <span className="text-[#64748b]">{CATEGORY_ICONS[cat]}</span>
            <h2 className="text-sm font-bold uppercase tracking-widest text-[#64748b] font-mono">{cat}</h2>
            <div className="flex-1 h-px bg-[#1e2d50]" />
            <span className="text-[10px] text-[#3d526b] font-mono">{TOOLS.filter(t => t.category === cat).length} tools</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {TOOLS.filter(t => t.category === cat).map(tool => (
              <button
                key={tool.id}
                onClick={() => onSelectTool(tool.id)}
                className="tool-card rounded-2xl p-5 text-left group relative overflow-hidden"
              >
                {/* Background glow */}
                <div
                  className="absolute top-0 right-0 w-28 h-28 rounded-bl-full opacity-5 group-hover:opacity-15 transition-opacity duration-500"
                  style={{ background: tool.color }}
                />

                {/* Icon */}
                <div
                  className="w-10 h-10 rounded-xl mb-3 flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110 duration-300"
                  style={{ background: tool.color + '20', color: tool.color, border: `1px solid ${tool.color}30` }}
                >
                  {tool.icon}
                </div>

                {/* Label + badge */}
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  <h3 className="font-bold text-sm text-white leading-tight">{tool.label}</h3>
                  {tool.badge && (
                    <span
                      className="badge px-1.5 py-0.5 rounded text-[9px]"
                      style={{ background: tool.color + '22', color: tool.color, border: `1px solid ${tool.color}44` }}
                    >
                      {tool.badge}
                    </span>
                  )}
                </div>

                <p className="text-xs text-[#64748b] leading-relaxed">{tool.description}</p>

                {/* Open hint */}
                <div
                  className="flex items-center gap-1 mt-3 text-xs font-semibold opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-0 group-hover:translate-x-1"
                  style={{ color: tool.color }}
                >
                  Open Tool <ChevronRight size={12} />
                </div>
              </button>
            ))}
          </div>
        </div>
      ))}

      {/* Quick start */}
      <div className="mt-4 mb-12 bg-[#0f1629] border border-[#1e2d50] rounded-2xl p-6 sm:p-8">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2 text-white">🚀 Quick Start</h2>
          <p className="text-[#64748b] text-sm mb-6 max-w-lg mx-auto">
            Pick any tool from the sidebar or above to get started instantly. No login, no setup — just build.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl mx-auto">
            {['json', 'beautifier', 'faker', 'contrast'].map(id => {
              const tool = TOOLS.find(t => t.id === id)!;
              return (
                <button key={id} onClick={() => onSelectTool(id)}
                  className="flex flex-col items-center gap-2 py-3 px-2 rounded-xl border border-[#1e2d50] hover:border-[#1e2d50] transition-all btn-secondary group">
                  <span style={{ color: tool.color }}>{tool.icon}</span>
                  <span className="text-xs text-center text-[#94a3b8] group-hover:text-white transition-colors leading-tight">{tool.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [activeTool, setActiveTool] = useState<string>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const ActiveComponent = TOOLS.find(t => t.id === activeTool)?.component;
  const activeMeta = TOOLS.find(t => t.id === activeTool);

  // Clock
  useEffect(() => {
    const tick = () => {
      const el = document.getElementById('clock');
      if (el) el.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="flex h-screen overflow-hidden grid-bg" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <Sidebar
        activeTool={activeTool}
        setActiveTool={setActiveTool}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center gap-3 px-4 sm:px-6 py-3 border-b border-[#1e2d50] bg-[#0a0e1a]/90 backdrop-blur-md flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-[#64748b] hover:text-white p-1.5 rounded-lg hover:bg-[#1e2d50] transition-all"
          >
            <Menu size={18} />
          </button>

          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs font-mono min-w-0">
            <button
              onClick={() => setActiveTool('home')}
              className="text-[#64748b] hover:text-[#00d4ff] transition-colors shrink-0"
            >
              ~/devtools
            </button>
            {activeMeta && (
              <>
                <span className="text-[#1e2d50]">/</span>
                <span className="truncate" style={{ color: activeMeta.color }}>{activeMeta.id}</span>
              </>
            )}
          </div>

          {/* Right actions */}
          <div className="ml-auto flex items-center gap-2">
            {activeTool !== 'home' && activeMeta && (
              <span
                className="hidden sm:flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1 rounded-full border"
                style={{ color: activeMeta.color, borderColor: activeMeta.color + '40', background: activeMeta.color + '10' }}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: activeMeta.color }} />
                {activeMeta.category}
              </span>
            )}
            <button
              onClick={() => setActiveTool('home')}
              className="btn-secondary text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5"
            >
              <Terminal size={12} />
              <span className="hidden sm:inline">Home</span>
            </button>
          </div>
        </header>

        {/* Main */}
        <main className="flex-1 overflow-y-auto">
          <div className="p-4 sm:p-6 min-h-full">
            {activeTool === 'home' ? (
              <HomePage onSelectTool={setActiveTool} />
            ) : ActiveComponent ? (
              <ActiveComponent />
            ) : null}
          </div>
        </main>
      </div>
    </div>
  );
}
