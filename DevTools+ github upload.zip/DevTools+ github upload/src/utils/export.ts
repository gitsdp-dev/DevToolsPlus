export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function copyToClipboard(text: string): Promise<void> {
  return navigator.clipboard.writeText(text);
}

export const EXPORT_FORMATS = {
  json: { label: 'JSON', ext: 'json', mime: 'application/json' },
  txt: { label: 'TXT', ext: 'txt', mime: 'text/plain' },
  html: { label: 'HTML', ext: 'html', mime: 'text/html' },
  css: { label: 'CSS', ext: 'css', mime: 'text/css' },
  js: { label: 'JS', ext: 'js', mime: 'application/javascript' },
  ts: { label: 'TS', ext: 'ts', mime: 'application/typescript' },
  svg: { label: 'SVG', ext: 'svg', mime: 'image/svg+xml' },
  xml: { label: 'XML', ext: 'xml', mime: 'application/xml' },
  md: { label: 'MD', ext: 'md', mime: 'text/markdown' },
  csv: { label: 'CSV', ext: 'csv', mime: 'text/csv' },
  ico: { label: 'ICO', ext: 'ico', mime: 'image/x-icon' },
  png: { label: 'PNG', ext: 'png', mime: 'image/png' },
};
