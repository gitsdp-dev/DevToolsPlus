import { ReactNode } from 'react';

interface ToolLayoutProps {
  title: string;
  description: string;
  icon: ReactNode;
  children: ReactNode;
  badge?: string;
}

export default function ToolLayout({ title, description, icon, children, badge }: ToolLayoutProps) {
  return (
    <div className="animate-slide-in h-full">
      <div className="flex items-start gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-[#00d4ff] bg-[#0f1629] border border-[#1e2d50] flex-shrink-0">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-white">{title}</h1>
            {badge && (
              <span className="badge px-2 py-0.5 rounded-full bg-[#7c3aed]/20 text-[#a78bfa] border border-[#7c3aed]/30">
                {badge}
              </span>
            )}
          </div>
          <p className="text-[#64748b] text-sm mt-0.5">{description}</p>
        </div>
      </div>
      {children}
    </div>
  );
}
