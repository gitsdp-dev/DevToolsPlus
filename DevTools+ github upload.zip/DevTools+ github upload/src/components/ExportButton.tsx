import { useState, useRef, useEffect } from 'react';
import { Download, ChevronDown, Copy, Check } from 'lucide-react';
import { downloadFile, copyToClipboard } from '../utils/export';

interface ExportOption {
  label: string;
  ext: string;
  mime: string;
  content?: string;
}

interface ExportButtonProps {
  formats: ExportOption[];
  defaultContent: string;
  defaultFilename: string;
  onCopy?: () => string;
  label?: string;
}

export default function ExportButton({ formats, defaultContent, defaultFilename, onCopy, label = 'Export' }: ExportButtonProps) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleCopy = async () => {
    const text = onCopy ? onCopy() : defaultContent;
    await copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    setOpen(false);
  };

  const handleDownload = (fmt: ExportOption) => {
    const content = fmt.content !== undefined ? fmt.content : defaultContent;
    downloadFile(content, `${defaultFilename}.${fmt.ext}`, fmt.mime);
    setOpen(false);
  };

  return (
    <div className="relative" ref={ref}>
      <div className="flex">
        <button
          onClick={() => formats.length > 0 && handleDownload(formats[0])}
          className="btn-primary flex items-center gap-2 px-4 py-2 rounded-l-lg text-sm"
        >
          <Download size={15} />
          {label}
        </button>
        <button
          onClick={() => setOpen(v => !v)}
          className="btn-primary px-2 py-2 rounded-r-lg text-sm border-l border-white/20"
        >
          <ChevronDown size={15} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
        </button>
      </div>
      {open && (
        <div className="absolute right-0 top-full mt-1 z-50 min-w-[160px] bg-[#0f1629] border border-[#1e2d50] rounded-lg shadow-2xl overflow-hidden animate-slide-in">
          <button
            onClick={handleCopy}
            className="w-full flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-[#141d35] transition-colors text-left"
          >
            {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} className="text-[#00d4ff]" />}
            <span>{copied ? 'Copied!' : 'Copy to Clipboard'}</span>
          </button>
          <div className="h-px bg-[#1e2d50]" />
          {formats.map(fmt => (
            <button
              key={fmt.ext}
              onClick={() => handleDownload(fmt)}
              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-[#141d35] transition-colors text-left"
            >
              <Download size={14} className="text-[#7c3aed]" />
              <span>Download as .{fmt.ext}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
