import { useState, useRef, useEffect, useCallback } from 'react';
import { Image, Download, Copy, Check } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';

type Shape = 'square' | 'circle' | 'rounded' | 'shield' | 'diamond';
type BgType = 'solid' | 'gradient' | 'transparent';

interface FavConfig {
  text: string;
  fontSize: number;
  fontWeight: string;
  bgColor: string;
  textColor: string;
  shape: Shape;
  gradColor: string;
  borderRadius: number;
  bgType: BgType;
}

const SIZES = [16, 32, 48, 64, 128, 192, 256];

export default function FaviconGenerator() {
  const mainCanvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);
  const [cfg, setCfg] = useState<FavConfig>({
    text: 'DT',
    fontSize: 72,
    fontWeight: '900',
    bgColor: '#00d4ff',
    textColor: '#0a0e1a',
    shape: 'rounded',
    gradColor: '#7c3aed',
    borderRadius: 30,
    bgType: 'gradient',
  });

  const set = (k: keyof FavConfig, v: unknown) => setCfg(p => ({ ...p, [k]: v }));

  const drawOnCanvas = useCallback((canvas: HTMLCanvasElement, size: number) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = size;
    canvas.height = size;
    ctx.clearRect(0, 0, size, size);

    const r = (cfg.borderRadius / 256) * size;

    ctx.save();

    // Clip path
    ctx.beginPath();
    if (cfg.shape === 'circle') {
      ctx.arc(size / 2, size / 2, size / 2 - 1, 0, Math.PI * 2);
    } else if (cfg.shape === 'square') {
      ctx.rect(0, 0, size, size);
    } else if (cfg.shape === 'rounded') {
      const br = Math.min(r, size / 3);
      ctx.moveTo(br, 0);
      ctx.lineTo(size - br, 0);
      ctx.quadraticCurveTo(size, 0, size, br);
      ctx.lineTo(size, size - br);
      ctx.quadraticCurveTo(size, size, size - br, size);
      ctx.lineTo(br, size);
      ctx.quadraticCurveTo(0, size, 0, size - br);
      ctx.lineTo(0, br);
      ctx.quadraticCurveTo(0, 0, br, 0);
      ctx.closePath();
    } else if (cfg.shape === 'shield') {
      ctx.moveTo(size / 2, 2);
      ctx.lineTo(size - 2, size * 0.28);
      ctx.lineTo(size - 2, size * 0.65);
      ctx.lineTo(size / 2, size - 2);
      ctx.lineTo(2, size * 0.65);
      ctx.lineTo(2, size * 0.28);
      ctx.closePath();
    } else if (cfg.shape === 'diamond') {
      ctx.moveTo(size / 2, 2);
      ctx.lineTo(size - 2, size / 2);
      ctx.lineTo(size / 2, size - 2);
      ctx.lineTo(2, size / 2);
      ctx.closePath();
    }
    ctx.clip();

    // Background
    if (cfg.bgType !== 'transparent') {
      if (cfg.bgType === 'gradient') {
        const grad = ctx.createLinearGradient(0, 0, size, size);
        grad.addColorStop(0, cfg.bgColor);
        grad.addColorStop(1, cfg.gradColor);
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = cfg.bgColor;
      }
      ctx.fillRect(0, 0, size, size);
    }

    ctx.restore();

    // Text
    const fs = (cfg.fontSize / 256) * size;
    ctx.fillStyle = cfg.textColor;
    ctx.font = `${cfg.fontWeight} ${Math.max(8, fs)}px Inter, Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(cfg.text.slice(0, 3), size / 2, size / 2 + size * 0.04);
  }, [cfg]);

  useEffect(() => {
    if (mainCanvasRef.current) {
      drawOnCanvas(mainCanvasRef.current, 256);
    }
  }, [drawOnCanvas]);

  const downloadAs = (size: number) => {
    const canvas = document.createElement('canvas');
    drawOnCanvas(canvas, size);
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `favicon-${size}x${size}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const downloadAll = () => {
    SIZES.forEach((size, i) => {
      setTimeout(() => downloadAs(size), i * 200);
    });
  };

  const copyHtmlTags = () => {
    const tags = SIZES.map(s => `<link rel="${s <= 32 ? 'icon' : s <= 64 ? 'icon' : 'apple-touch-icon'}" type="image/png" sizes="${s}x${s}" href="/favicon-${s}x${s}.png">`).join('\n');
    navigator.clipboard.writeText(tags).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const htmlTags = `<!-- Favicon Links -->
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="48x48" href="/favicon-48x48.png">
<link rel="icon" type="image/png" sizes="64x64" href="/favicon-64x64.png">
<link rel="apple-touch-icon" sizes="128x128" href="/favicon-128x128.png">
<link rel="apple-touch-icon" sizes="192x192" href="/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="256x256" href="/favicon-256x256.png">`;

  return (
    <ToolLayout
      title="Favicon Generator"
      description="Create favicon icons in multiple sizes with live canvas preview"
      icon={<Image size={20} />}
      badge="Multi-Size"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="space-y-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Text / Initials (max 3)</label>
            <input
              value={cfg.text}
              maxLength={3}
              onChange={e => set('text', e.target.value.toUpperCase())}
              className="input-field w-full px-3 py-2.5 rounded-xl text-lg font-black text-center tracking-widest"
              placeholder="DT"
            />
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Shape</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['square', 'circle', 'rounded', 'shield', 'diamond'] as Shape[]).map(s => (
                <button key={s} onClick={() => set('shape', s)}
                  className={`py-2 px-2 rounded-lg text-xs capitalize transition-all ${cfg.shape === s ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          {cfg.shape === 'rounded' && (
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#64748b] font-mono uppercase tracking-wider">Corner Radius</span>
                <span className="text-[#00d4ff] font-mono">{cfg.borderRadius}px</span>
              </div>
              <input type="range" min="0" max="100" value={cfg.borderRadius}
                onChange={e => set('borderRadius', +e.target.value)} className="w-full" />
            </div>
          )}

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Background</label>
            <div className="flex gap-1 mb-3">
              {(['solid', 'gradient', 'transparent'] as BgType[]).map(t => (
                <button key={t} onClick={() => set('bgType', t)}
                  className={`flex-1 py-1.5 rounded-lg text-xs capitalize transition-all ${cfg.bgType === t ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                  {t}
                </button>
              ))}
            </div>
            {cfg.bgType !== 'transparent' && (
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="text-xs text-[#64748b] block mb-1">Color 1</label>
                  <input type="color" value={cfg.bgColor} onChange={e => set('bgColor', e.target.value)}
                    className="w-full h-10 rounded-xl border border-[#1e2d50] cursor-pointer bg-transparent" />
                </div>
                {cfg.bgType === 'gradient' && (
                  <div className="flex-1">
                    <label className="text-xs text-[#64748b] block mb-1">Color 2</label>
                    <input type="color" value={cfg.gradColor} onChange={e => set('gradColor', e.target.value)}
                      className="w-full h-10 rounded-xl border border-[#1e2d50] cursor-pointer bg-transparent" />
                  </div>
                )}
              </div>
            )}
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Text Color</label>
            <input type="color" value={cfg.textColor} onChange={e => set('textColor', e.target.value)}
              className="w-full h-10 rounded-xl border border-[#1e2d50] cursor-pointer bg-transparent" />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#64748b] font-mono uppercase tracking-wider">Font Size</span>
              <span className="text-[#00d4ff] font-mono">{cfg.fontSize}px</span>
            </div>
            <input type="range" min="20" max="180" value={cfg.fontSize}
              onChange={e => set('fontSize', +e.target.value)} className="w-full" />
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Font Weight</label>
            <select value={cfg.fontWeight} onChange={e => set('fontWeight', e.target.value)}
              className="input-field w-full px-3 py-2 rounded-xl text-sm">
              {[['400','Regular'],['600','Semibold'],['700','Bold'],['800','Extrabold'],['900','Black']].map(([v, l]) => (
                <option key={v} value={v}>{l} ({v})</option>
              ))}
            </select>
          </div>
        </div>

        {/* Preview & Download */}
        <div className="lg:col-span-2 space-y-6">
          {/* Hidden main canvas for reference */}
          <canvas ref={mainCanvasRef} className="hidden" />

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-3">Preview at All Sizes</label>
            <div className="preview-box rounded-xl p-6 border border-[#1e2d50] flex flex-wrap gap-5 items-end justify-center">
              {SIZES.map(size => {
                const displaySize = Math.min(size, 128);
                return (
                  <div key={size} className="flex flex-col items-center gap-2">
                    <div className="border border-[#1e2d50] rounded-lg overflow-hidden"
                      style={{ width: displaySize, height: displaySize }}>
                      <canvas
                        width={displaySize}
                        height={displaySize}
                        className="canvas-preview"
                        ref={el => {
                          if (el) {
                            drawOnCanvas(el, displaySize);
                          }
                        }}
                        style={{ width: displaySize, height: displaySize }}
                      />
                    </div>
                    <span className="text-[10px] text-[#64748b] font-mono">{size}×{size}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-3">Download by Size</label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {SIZES.map(size => (
                <button key={size} onClick={() => downloadAs(size)}
                  className="btn-secondary flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm transition-all">
                  <Download size={14} className="text-[#00d4ff]" />
                  {size}×{size}
                </button>
              ))}
              <button onClick={downloadAll}
                className="btn-green col-span-1 sm:col-span-2 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm">
                <Download size={14} /> Download All
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">HTML Link Tags</label>
              <button onClick={copyHtmlTags}
                className="flex items-center gap-1.5 text-xs text-[#00d4ff] hover:text-white transition-colors">
                {copied ? <><Check size={12} /> Copied!</> : <><Copy size={12} /> Copy</>}
              </button>
            </div>
            <textarea readOnly rows={8} value={htmlTags}
              className="code-area w-full rounded-xl p-4 text-xs" spellCheck={false} />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
