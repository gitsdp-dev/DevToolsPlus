import { useState } from 'react';
import { Sparkles, FileCode } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

type Lang = 'html' | 'css' | 'javascript' | 'typescript' | 'json';

function beautifyHTML(code: string, indent = 2): string {
  const sp = ' '.repeat(indent);
  let result = '';
  let level = 0;
  const voidTags = new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
  const raw = code.replace(/>\s*</g, '><').trim();
  const tokens = raw.split(/(<[^>]+>)/g).filter(Boolean);
  for (const token of tokens) {
    if (token.startsWith('</')) {
      level = Math.max(0, level - 1);
      result += sp.repeat(level) + token + '\n';
    } else if (token.startsWith('<') && !token.startsWith('<!') && !token.endsWith('/>')) {
      const tagName = (token.match(/<([a-zA-Z][a-zA-Z0-9]*)/) || [])[1]?.toLowerCase();
      result += sp.repeat(level) + token + '\n';
      if (tagName && !voidTags.has(tagName)) level++;
    } else if (token.trim()) {
      result += sp.repeat(level) + token.trim() + '\n';
    }
  }
  return result.trimEnd();
}

function beautifyCSS(code: string, indent = 2): string {
  const sp = ' '.repeat(indent);
  let result = '';
  let level = 0;
  const tokens = code
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\{/g, ' {\n').replace(/\}/g, '\n}\n')
    .replace(/;/g, ';\n').split('\n');
  for (let line of tokens) {
    line = line.trim();
    if (!line) continue;
    if (line.endsWith('{')) {
      result += sp.repeat(level) + line + '\n';
      level++;
    } else if (line === '}') {
      level = Math.max(0, level - 1);
      result += sp.repeat(level) + line + '\n';
    } else {
      result += sp.repeat(level) + line + '\n';
    }
  }
  return result.replace(/\n{3,}/g, '\n\n').trim();
}

function beautifyJS(code: string, indent = 2): string {
  const sp = ' '.repeat(indent);
  const lines = code.split('\n').map(l => l.trim()).filter(Boolean);
  let level = 0;
  let result = '';
  for (const line of lines) {
    const opens = (line.match(/[{[(]/g) || []).length;
    const closes = (line.match(/[}\])]/g) || []).length;
    if (closes > opens) level = Math.max(0, level - (closes - opens));
    result += sp.repeat(level) + line + '\n';
    if (opens > closes) level += opens - closes;
  }
  return result.trimEnd();
}

const SAMPLE: Record<Lang, string> = {
  html: '<html><head><title>Hello</title></head><body><div class="container"><h1>Hello World</h1><p>This is a paragraph</p></div></body></html>',
  css: '.container{display:flex;flex-direction:column;align-items:center;}.title{font-size:2rem;color:#333;font-weight:bold;}a:hover{color:blue;text-decoration:underline;}',
  javascript: 'function greet(name){const message=`Hello, ${name}!`;console.log(message);return message;}const users=[{id:1,name:"Alice"},{id:2,name:"Bob"}];users.forEach(u=>greet(u.name));',
  typescript: 'interface User{id:number;name:string;email:string;}function getUser(id:number):User{return{id,name:"Alice",email:"alice@example.com"};}const user:User=getUser(1);console.log(user);',
  json: '{"name":"DevTools","version":"1.0","features":["formatter","beautifier"],"config":{"indent":2,"theme":"dark"}}',
};

const MIME: Record<Lang, string> = {
  html: 'text/html', css: 'text/css',
  javascript: 'application/javascript', typescript: 'application/typescript',
  json: 'application/json',
};
const EXT: Record<Lang, string> = {
  html: 'html', css: 'css', javascript: 'js', typescript: 'ts', json: 'json',
};

export default function CodeBeautifier() {
  const [lang, setLang] = useState<Lang>('javascript');
  const [input, setInput] = useState(SAMPLE.javascript);
  const [output, setOutput] = useState('');
  const [indent, setIndent] = useState(2);

  const beautify = () => {
    let result = '';
    switch (lang) {
      case 'html': result = beautifyHTML(input, indent); break;
      case 'css': result = beautifyCSS(input, indent); break;
      case 'json':
        try { result = JSON.stringify(JSON.parse(input), null, indent); } catch { result = '// Invalid JSON'; }
        break;
      default: result = beautifyJS(input, indent);
    }
    setOutput(result);
  };

  const handleLangChange = (l: Lang) => {
    setLang(l);
    setInput(SAMPLE[l]);
    setOutput('');
  };

  return (
    <ToolLayout
      title="Code Beautifier"
      description="Format and beautify HTML, CSS, JavaScript, TypeScript, and JSON code"
      icon={<Sparkles size={20} />}
      badge="Multi-Language"
    >
      <div className="flex flex-wrap gap-3 mb-4 items-center">
        <div className="flex bg-[#060a14] border border-[#1e2d50] rounded-xl p-1 gap-1">
          {(['html', 'css', 'javascript', 'typescript', 'json'] as Lang[]).map(l => (
            <button
              key={l}
              onClick={() => handleLangChange(l)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all uppercase ${lang === l ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              {l === 'javascript' ? 'JS' : l === 'typescript' ? 'TS' : l.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 text-sm">
          <label className="text-[#64748b]">Indent:</label>
          <select value={indent} onChange={e => setIndent(+e.target.value)} className="input-field px-2 py-1 rounded-lg text-sm w-16">
            {[2, 4, 6, 8].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-1 ml-auto">
          <FileCode size={14} className="text-[#00d4ff]" />
          <span className="text-xs text-[#64748b] uppercase font-mono">{lang}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Input Code</label>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            className="code-area rounded-xl p-4 min-h-[380px] w-full"
            placeholder="Paste your code here..."
            spellCheck={false}
          />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Beautified Output</label>
          <textarea
            readOnly
            value={output}
            className="code-area rounded-xl p-4 min-h-[380px] w-full"
            placeholder="Beautified code will appear here..."
            spellCheck={false}
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-3 mt-4 items-center">
        <button onClick={beautify} className="btn-primary px-5 py-2 rounded-xl text-sm flex items-center gap-2">
          <Sparkles size={14} /> Beautify Code
        </button>
        <button onClick={() => { setInput(SAMPLE[lang]); setOutput(''); }} className="btn-secondary px-5 py-2 rounded-xl text-sm">
          Reset
        </button>
        <div className="ml-auto">
          <ExportButton
            formats={[
              { label: EXT[lang].toUpperCase(), ext: EXT[lang], mime: MIME[lang] },
              { label: 'TXT', ext: 'txt', mime: 'text/plain' },
            ]}
            defaultContent={output}
            defaultFilename={`beautified.${EXT[lang]}`}
            label="Export"
          />
        </div>
      </div>
    </ToolLayout>
  );
}
