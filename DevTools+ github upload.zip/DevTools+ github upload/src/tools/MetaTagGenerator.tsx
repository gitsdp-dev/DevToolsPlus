import { useState } from 'react';
import { Tag } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

interface MetaConfig {
  title: string;
  description: string;
  keywords: string;
  author: string;
  robots: string;
  canonical: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogType: string;
  ogUrl: string;
  twitterCard: string;
  twitterTitle: string;
  twitterDescription: string;
  twitterImage: string;
  twitterSite: string;
  themeColor: string;
  viewport: string;
  charset: string;
}

export default function MetaTagGenerator() {
  const [cfg, setCfg] = useState<MetaConfig>({
    title: 'My Awesome Website',
    description: 'A description of my awesome website for search engines.',
    keywords: 'web, development, react, javascript',
    author: 'John Doe',
    robots: 'index, follow',
    canonical: 'https://example.com',
    ogTitle: 'My Awesome Website',
    ogDescription: 'A description of my awesome website for search engines.',
    ogImage: 'https://example.com/og-image.jpg',
    ogType: 'website',
    ogUrl: 'https://example.com',
    twitterCard: 'summary_large_image',
    twitterTitle: 'My Awesome Website',
    twitterDescription: 'A description of my awesome website for search engines.',
    twitterImage: 'https://example.com/og-image.jpg',
    twitterSite: '@yourtwitterhandle',
    themeColor: '#00d4ff',
    viewport: 'width=device-width, initial-scale=1.0',
    charset: 'UTF-8',
  });

  const set = (k: keyof MetaConfig, v: string) => setCfg(p => ({ ...p, [k]: v }));

  const generateMeta = (): string => {
    const lines: string[] = [
      `<!-- Basic Meta Tags -->`,
      `<meta charset="${cfg.charset}">`,
      `<meta name="viewport" content="${cfg.viewport}">`,
      `<title>${cfg.title}</title>`,
      cfg.description ? `<meta name="description" content="${cfg.description}">` : '',
      cfg.keywords ? `<meta name="keywords" content="${cfg.keywords}">` : '',
      cfg.author ? `<meta name="author" content="${cfg.author}">` : '',
      cfg.robots ? `<meta name="robots" content="${cfg.robots}">` : '',
      cfg.themeColor ? `<meta name="theme-color" content="${cfg.themeColor}">` : '',
      cfg.canonical ? `<link rel="canonical" href="${cfg.canonical}">` : '',
      ``,
      `<!-- Open Graph / Facebook -->`,
      cfg.ogType ? `<meta property="og:type" content="${cfg.ogType}">` : '',
      cfg.ogUrl ? `<meta property="og:url" content="${cfg.ogUrl}">` : '',
      cfg.ogTitle ? `<meta property="og:title" content="${cfg.ogTitle}">` : '',
      cfg.ogDescription ? `<meta property="og:description" content="${cfg.ogDescription}">` : '',
      cfg.ogImage ? `<meta property="og:image" content="${cfg.ogImage}">` : '',
      ``,
      `<!-- Twitter -->`,
      cfg.twitterCard ? `<meta name="twitter:card" content="${cfg.twitterCard}">` : '',
      cfg.twitterSite ? `<meta name="twitter:site" content="${cfg.twitterSite}">` : '',
      cfg.twitterTitle ? `<meta name="twitter:title" content="${cfg.twitterTitle}">` : '',
      cfg.twitterDescription ? `<meta name="twitter:description" content="${cfg.twitterDescription}">` : '',
      cfg.twitterImage ? `<meta name="twitter:image" content="${cfg.twitterImage}">` : '',
    ].filter(l => l !== undefined) as string[];
    return lines.join('\n');
  };

  const output = generateMeta();

  const Field = ({ label, k, placeholder, multiline }: { label: string; k: keyof MetaConfig; placeholder?: string; multiline?: boolean }) => (
    <div>
      <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">{label}</label>
      {multiline ? (
        <textarea value={cfg[k]} onChange={e => set(k, e.target.value)}
          className="input-field w-full px-3 py-2 rounded-xl text-sm resize-none" rows={2} placeholder={placeholder} />
      ) : (
        <input value={cfg[k]} onChange={e => set(k, e.target.value)}
          className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder={placeholder} />
      )}
    </div>
  );

  return (
    <ToolLayout
      title="Meta Tag Generator"
      description="Generate comprehensive HTML meta tags for SEO and social sharing"
      icon={<Tag size={20} />}
      badge="SEO"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-5">
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#00d4ff] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00d4ff] inline-block" /> Basic Meta
            </h3>
            <Field label="Page Title" k="title" placeholder="My Awesome Website" />
            <Field label="Description" k="description" placeholder="Page description..." multiline />
            <Field label="Keywords" k="keywords" placeholder="keyword1, keyword2, keyword3" />
            <Field label="Author" k="author" placeholder="John Doe" />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Robots</label>
                <select value={cfg.robots} onChange={e => set('robots', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm">
                  {['index, follow', 'noindex, follow', 'index, nofollow', 'noindex, nofollow'].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Charset</label>
                <select value={cfg.charset} onChange={e => set('charset', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm">
                  {['UTF-8', 'ISO-8859-1', 'UTF-16'].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
            </div>
            <Field label="Canonical URL" k="canonical" placeholder="https://example.com" />
            <div className="flex items-center gap-3">
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Theme Color</label>
                <input type="color" value={cfg.themeColor} onChange={e => set('themeColor', e.target.value)}
                  className="w-12 h-10 rounded-lg border border-[#1e2d50] cursor-pointer bg-transparent" />
              </div>
              <div className="flex-1">
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Viewport</label>
                <input value={cfg.viewport} onChange={e => set('viewport', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm" />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#7c3aed] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#7c3aed] inline-block" /> Open Graph
            </h3>
            <Field label="OG Title" k="ogTitle" />
            <Field label="OG Description" k="ogDescription" multiline />
            <Field label="OG Image URL" k="ogImage" placeholder="https://example.com/image.jpg" />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">OG Type</label>
                <select value={cfg.ogType} onChange={e => set('ogType', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm">
                  {['website', 'article', 'product', 'profile', 'video.movie'].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
              <Field label="OG URL" k="ogUrl" />
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#00ff88] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00ff88] inline-block" /> Twitter Card
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Card Type</label>
                <select value={cfg.twitterCard} onChange={e => set('twitterCard', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm">
                  {['summary', 'summary_large_image', 'app', 'player'].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
              <Field label="Twitter @site" k="twitterSite" placeholder="@handle" />
            </div>
            <Field label="Twitter Title" k="twitterTitle" />
            <Field label="Twitter Description" k="twitterDescription" multiline />
            <Field label="Twitter Image URL" k="twitterImage" placeholder="https://example.com/image.jpg" />
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="sticky top-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Generated HTML</label>
              <span className="text-xs text-[#64748b] font-mono">{output.split('\n').filter(Boolean).length} tags</span>
            </div>
            <textarea readOnly value={output} className="code-area rounded-xl p-4 w-full text-xs"
              rows={28} spellCheck={false} />
            <div className="flex justify-end mt-3">
              <ExportButton
                formats={[
                  { label: 'HTML', ext: 'html', mime: 'text/html', content: `<!DOCTYPE html>\n<html lang="en">\n<head>\n${output}\n</head>\n<body></body>\n</html>` },
                  { label: 'TXT', ext: 'txt', mime: 'text/plain', content: output },
                  { label: 'MD', ext: 'md', mime: 'text/markdown', content: `## Meta Tags\n\n\`\`\`html\n${output}\n\`\`\`` },
                ]}
                defaultContent={output}
                defaultFilename="meta-tags"
                label="Export"
              />
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
