import { useState } from 'react';
import { Eye, CheckCircle, XCircle } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

function hexToRgb(hex: string): [number, number, number] | null {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return null;
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
}

function getLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map(c => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function getContrastRatio(hex1: string, hex2: string): number {
  const rgb1 = hexToRgb(hex1);
  const rgb2 = hexToRgb(hex2);
  if (!rgb1 || !rgb2) return 1;
  const l1 = getLuminance(...rgb1);
  const l2 = getLuminance(...rgb2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}

const PALETTES = [
  { name: 'Midnight Pro', fg: '#ffffff', bg: '#0a0e1a' },
  { name: 'Ocean Blue', fg: '#ffffff', bg: '#1a4f8a' },
  { name: 'Forest Green', fg: '#ffffff', bg: '#145a32' },
  { name: 'Sunset', fg: '#1a1a1a', bg: '#ff8c42' },
  { name: 'Candy Pink', fg: '#1a1a1a', bg: '#ff6b9d' },
  { name: 'Lemon', fg: '#1a1a1a', bg: '#f5f05a' },
  { name: 'Neon Cyan', fg: '#0a0e1a', bg: '#00d4ff' },
  { name: 'Terminal', fg: '#00ff88', bg: '#0d1117' },
];

export default function ColorContrastChecker() {
  const [fg, setFg] = useState('#ffffff');
  const [bg, setBg] = useState('#0a0e1a');
  const [fontSize, setFontSize] = useState(16);
  const [fontBold, setFontBold] = useState(false);

  const ratio = getContrastRatio(fg, bg);
  const ratioStr = ratio.toFixed(2);

  const isLargeText = fontSize >= 18 || (fontBold && fontSize >= 14);
  const passAANormal = ratio >= 4.5;
  const passAAANormal = ratio >= 7;
  const passAALarge = ratio >= 3;
  const passAAALarge = ratio >= 4.5;

  const level = ratio >= 7 ? 'AAA' : ratio >= 4.5 ? 'AA' : ratio >= 3 ? 'AA Large' : 'FAIL';
  const levelColor = ratio >= 7 ? '#00ff88' : ratio >= 4.5 ? '#00d4ff' : ratio >= 3 ? '#f59e0b' : '#ff4466';

  const fgRgb = hexToRgb(fg);
  const bgRgb = hexToRgb(bg);
  const fgHsl = fgRgb ? rgbToHsl(...fgRgb) : [0, 0, 0];
  const bgHsl = bgRgb ? rgbToHsl(...bgRgb) : [0, 0, 0];

  const reportContent = `Color Contrast Report
======================
Foreground: ${fg}
Background: ${bg}
Contrast Ratio: ${ratioStr}:1
WCAG Level: ${level}

WCAG 2.1 Results:
- AA Normal Text (4.5:1): ${passAANormal ? 'PASS' : 'FAIL'}
- AAA Normal Text (7:1): ${passAAANormal ? 'PASS' : 'FAIL'}
- AA Large Text (3:1): ${passAALarge ? 'PASS' : 'FAIL'}
- AAA Large Text (4.5:1): ${passAAALarge ? 'PASS' : 'FAIL'}`;

  return (
    <ToolLayout
      title="Color Contrast Checker"
      description="Check WCAG accessibility color contrast ratios for your designs"
      icon={<Eye size={20} />}
      badge="WCAG 2.1"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Foreground</label>
              <div className="flex flex-col gap-2">
                <input type="color" value={fg} onChange={e => setFg(e.target.value)}
                  className="w-full h-14 rounded-xl border border-[#1e2d50] cursor-pointer bg-transparent" />
                <input value={fg} onChange={e => { if (/^#[0-9a-fA-F]{0,6}$/.test(e.target.value)) setFg(e.target.value); }}
                  className="input-field px-3 py-2 rounded-xl text-sm text-center font-mono uppercase" maxLength={7} />
              </div>
            </div>
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Background</label>
              <div className="flex flex-col gap-2">
                <input type="color" value={bg} onChange={e => setBg(e.target.value)}
                  className="w-full h-14 rounded-xl border border-[#1e2d50] cursor-pointer bg-transparent" />
                <input value={bg} onChange={e => { if (/^#[0-9a-fA-F]{0,6}$/.test(e.target.value)) setBg(e.target.value); }}
                  className="input-field px-3 py-2 rounded-xl text-sm text-center font-mono uppercase" maxLength={7} />
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Quick Palettes</label>
            <div className="grid grid-cols-2 gap-1.5">
              {PALETTES.map(p => (
                <button key={p.name} onClick={() => { setFg(p.fg); setBg(p.bg); }}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-lg border border-[#1e2d50] hover:border-[#1e2d50] transition-all text-xs"
                  style={{ background: p.bg }}>
                  <span style={{ color: p.fg, fontWeight: 600 }}>{p.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#64748b] font-mono uppercase tracking-wider">Font Size</span>
              <span className="text-[#00d4ff] font-mono">{fontSize}px</span>
            </div>
            <input type="range" min="10" max="48" value={fontSize}
              onChange={e => setFontSize(+e.target.value)} className="w-full" />
          </div>

          <label className="flex items-center gap-2 text-sm text-[#64748b] cursor-pointer">
            <input type="checkbox" checked={fontBold} onChange={e => setFontBold(e.target.checked)} />
            Bold Font
          </label>

          {fgRgb && bgRgb && (
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-3 space-y-1">
              <div className="text-xs text-[#64748b] font-mono uppercase tracking-wider mb-2">Color Details</div>
              {[
                { label: 'FG RGB', value: `rgb(${fgRgb.join(', ')})` },
                { label: 'FG HSL', value: `hsl(${fgHsl[0]}, ${fgHsl[1]}%, ${fgHsl[2]}%)` },
                { label: 'BG RGB', value: `rgb(${bgRgb.join(', ')})` },
                { label: 'BG HSL', value: `hsl(${bgHsl[0]}, ${bgHsl[1]}%, ${bgHsl[2]}%)` },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between text-xs">
                  <span className="text-[#64748b]">{label}</span>
                  <span className="text-[#00d4ff] font-mono text-right">{value}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-2 flex flex-col gap-4">
          <div className="rounded-xl overflow-hidden border border-[#1e2d50]">
            <div className="p-6 flex flex-col gap-4" style={{ background: bg }}>
              <p style={{ color: fg, fontSize: `${fontSize}px`, fontWeight: fontBold ? 700 : 400, margin: 0 }}>
                The quick brown fox jumps over the lazy dog
              </p>
              <p style={{ color: fg, fontSize: `${Math.max(10, fontSize - 4)}px`, fontWeight: fontBold ? 700 : 400, margin: 0 }}>
                ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 !@#$%^&*()
              </p>
              <p style={{ color: fg, fontSize: '14px', margin: 0, opacity: 0.8 }}>
                Accessibility matters. Good contrast improves readability for everyone, especially those with visual impairments.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 text-center">
              <div className="text-3xl font-black font-mono mb-1" style={{ color: levelColor }}>{ratioStr}</div>
              <div className="text-xs text-[#64748b]">Contrast Ratio</div>
            </div>
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 text-center">
              <div className="text-2xl font-black mb-1" style={{ color: levelColor }}>{level}</div>
              <div className="text-xs text-[#64748b]">WCAG Level</div>
            </div>
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 text-center">
              <div className="text-lg font-bold mb-1">{isLargeText ? 'Large' : 'Normal'}</div>
              <div className="text-xs text-[#64748b]">Text Type</div>
            </div>
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 text-center">
              <div className="text-2xl font-black mb-1" style={{ color: ratio >= 4.5 ? '#00ff88' : '#ff4466' }}>
                {ratio >= 4.5 ? '✓' : '✗'}
              </div>
              <div className="text-xs text-[#64748b]">AA Compliant</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'AA Normal Text', req: '4.5:1', pass: passAANormal },
              { label: 'AAA Normal Text', req: '7:1', pass: passAAANormal },
              { label: 'AA Large Text', req: '3:1', pass: passAALarge },
              { label: 'AAA Large Text', req: '4.5:1', pass: passAAALarge },
            ].map(({ label, req, pass }) => (
              <div key={label} className={`flex items-center gap-3 p-3 rounded-xl border ${pass ? 'bg-[#00ff88]/5 border-[#00ff88]/20' : 'bg-[#ff4466]/5 border-[#ff4466]/20'}`}>
                {pass ? <CheckCircle size={18} className="text-[#00ff88] flex-shrink-0" /> : <XCircle size={18} className="text-[#ff4466] flex-shrink-0" />}
                <div>
                  <div className="text-sm font-medium">{label}</div>
                  <div className="text-xs text-[#64748b]">Requires {req}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'TXT', ext: 'txt', mime: 'text/plain', content: reportContent },
                { label: 'MD', ext: 'md', mime: 'text/markdown', content: `## Color Contrast Report\n\n${reportContent}` },
                { label: 'JSON', ext: 'json', mime: 'application/json', content: JSON.stringify({ foreground: fg, background: bg, ratio: +ratioStr, level, wcag: { aaSmall: passAANormal, aaaSmall: passAAANormal, aaLarge: passAALarge, aaaLarge: passAAALarge } }, null, 2) },
              ]}
              defaultContent={reportContent}
              defaultFilename="contrast-report"
              label="Export Report"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
