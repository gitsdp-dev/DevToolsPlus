import { useState, useMemo } from 'react';
import { Waves } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

type WaveType = 'sine' | 'layered' | 'sharp' | 'smooth' | 'blob';

interface WaveConfig {
  type: WaveType;
  width: number;
  height: number;
  amplitude: number;
  frequency: number;
  color1: string;
  color2: string;
  color3: string;
  layers: number;
  flip: boolean;
  opacity1: number;
  opacity2: number;
  opacity3: number;
}

function generatePath(width: number, height: number, amplitude: number, frequency: number, offset: number, type: WaveType): string {
  const points: string[] = [];
  const step = width / 100;

  if (type === 'sharp') {
    let d = `M 0 ${height}`;
    for (let i = 0; i <= 100; i++) {
      const x = i * step;
      const y = height / 2 + (i % (100 / frequency) < (50 / frequency) ? -amplitude : amplitude) + offset;
      d += ` L ${x} ${y}`;
    }
    return d + ` L ${width} ${height} Z`;
  }

  for (let i = 0; i <= 100; i++) {
    const x = i * step;
    const rad = (i / 100) * Math.PI * 2 * frequency;
    const y = height / 2 + Math.sin(rad) * amplitude + offset;
    points.push(`${x},${y}`);
  }

  const pts = points.map((p, i) => {
    if (i === 0) return `M 0 ${height} L ${p}`;
    return `L ${p}`;
  });
  return pts.join(' ') + ` L ${width} ${height} Z`;
}

function generateSmoothPath(width: number, height: number, amplitude: number, frequency: number, offset: number): string {
  const numPoints = Math.ceil(frequency * 4);
  const segW = width / numPoints;
  let d = `M 0 ${height}`;
  d += ` L 0 ${height / 2 + offset}`;
  for (let i = 0; i < numPoints; i++) {
    const x1 = i * segW + segW / 2;
    const x2 = (i + 1) * segW;
    const y1 = i % 2 === 0 ? height / 2 - amplitude + offset : height / 2 + amplitude + offset;
    const y2 = i % 2 === 0 ? height / 2 + amplitude + offset : height / 2 - amplitude + offset;
    d += ` C ${x1} ${y1} ${x1} ${y1} ${x2} ${y2}`;
  }
  d += ` L ${width} ${height} Z`;
  return d;
}

function generateBlobPath(width: number, height: number, amplitude: number): string {
  const cx = width / 2, cy = height / 2;
  const r = Math.min(width, height) * 0.35;
  const pts = 8;
  const points: [number, number][] = [];
  for (let i = 0; i < pts; i++) {
    const angle = (i / pts) * Math.PI * 2;
    const rand = r + (Math.sin(i * 3.7) * amplitude * 0.6);
    points.push([cx + Math.cos(angle) * rand, cy + Math.sin(angle) * rand]);
  }
  let d = `M ${points[0][0]} ${points[0][1]}`;
  for (let i = 0; i < pts; i++) {
    const next = points[(i + 1) % pts];
    const cp1x = points[i][0] + (next[0] - points[(i - 1 + pts) % pts][0]) * 0.2;
    const cp1y = points[i][1] + (next[1] - points[(i - 1 + pts) % pts][1]) * 0.2;
    d += ` Q ${cp1x} ${cp1y} ${next[0]} ${next[1]}`;
  }
  return d + ' Z';
}

export default function SvgWaveGenerator() {
  const [cfg, setCfg] = useState<WaveConfig>({
    type: 'layered', width: 1200, height: 200, amplitude: 40, frequency: 2,
    color1: '#00d4ff', color2: '#7c3aed', color3: '#00ff88',
    layers: 2, flip: false,
    opacity1: 100, opacity2: 70, opacity3: 50,
  });

  const set = (k: keyof WaveConfig, v: unknown) => setCfg(p => ({ ...p, [k]: v }));

  const svgContent = useMemo(() => {
    const { width, height, amplitude, frequency, color1, color2, color3, layers, type, opacity1, opacity2, opacity3 } = cfg;
    const transform = cfg.flip ? `scale(1,-1) translate(0,-${height})` : '';

    if (type === 'blob') {
      const path = generateBlobPath(width, height, amplitude);
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}">
  <path d="${path}" fill="${color1}" opacity="${opacity1 / 100}" />
</svg>`;
    }

    const paths = Array.from({ length: layers }, (_, i) => {
      const colors = [color1, color2, color3];
      const opacities = [opacity1, opacity2, opacity3];
      const offset = i * (amplitude * 0.5);
      const amp = amplitude - i * (amplitude * 0.2);
      const path = type === 'smooth'
        ? generateSmoothPath(width, height, amp, frequency + i * 0.5, offset)
        : generatePath(width, height, amp, frequency + i * 0.3, offset, type);
      return `  <path d="${path}" fill="${colors[i % 3]}" opacity="${opacities[i % 3] / 100}" transform="${transform}" />`;
    });

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}">
${paths.join('\n')}
</svg>`;
  }, [cfg]);

  return (
    <ToolLayout
      title="SVG Wave Generator"
      description="Generate customizable SVG waves for backgrounds and dividers"
      icon={<Waves size={20} />}
      badge="SVG Export"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Wave Type</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(['sine', 'smooth', 'sharp', 'layered', 'blob'] as WaveType[]).map(t => (
                <button key={t} onClick={() => set('type', t)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-semibold capitalize transition-all ${cfg.type === t ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          {[
            { label: 'Width', key: 'width', min: 400, max: 2000, step: 100 },
            { label: 'Height', key: 'height', min: 60, max: 500, step: 10 },
            { label: 'Amplitude', key: 'amplitude', min: 5, max: 150, step: 5 },
            { label: 'Frequency', key: 'frequency', min: 1, max: 10, step: 0.5 },
            ...(cfg.type !== 'blob' ? [{ label: 'Layers', key: 'layers', min: 1, max: 3, step: 1 }] : []),
          ].map(({ label, key, min, max, step }) => (
            <div key={key}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#64748b] font-mono uppercase tracking-wider">{label}</span>
                <span className="text-[#00d4ff] font-mono">{cfg[key as keyof WaveConfig]}</span>
              </div>
              <input type="range" min={min} max={max} step={step} value={cfg[key as keyof WaveConfig] as number}
                onChange={e => set(key as keyof WaveConfig, +e.target.value)} className="w-full" />
            </div>
          ))}

          <label className="flex items-center gap-2 text-sm text-[#64748b] cursor-pointer">
            <input type="checkbox" checked={cfg.flip} onChange={e => set('flip', e.target.checked)} />
            Flip Vertically
          </label>

          <div className="space-y-2">
            {[
              { label: 'Color 1', key: 'color1', opKey: 'opacity1' },
              ...(cfg.layers >= 2 && cfg.type !== 'blob' ? [{ label: 'Color 2', key: 'color2', opKey: 'opacity2' }] : []),
              ...(cfg.layers >= 3 && cfg.type !== 'blob' ? [{ label: 'Color 3', key: 'color3', opKey: 'opacity3' }] : []),
            ].map(({ label, key, opKey }) => (
              <div key={key} className="flex items-center gap-3">
                <input type="color" value={cfg[key as keyof WaveConfig] as string}
                  onChange={e => set(key as keyof WaveConfig, e.target.value)}
                  className="w-10 h-8 rounded-lg border border-[#1e2d50] cursor-pointer bg-transparent flex-shrink-0" />
                <div className="flex-1">
                  <div className="flex justify-between text-xs mb-0.5">
                    <span className="text-[#64748b]">{label} opacity</span>
                    <span className="text-[#00d4ff]">{cfg[opKey as keyof WaveConfig]}%</span>
                  </div>
                  <input type="range" min="10" max="100" value={cfg[opKey as keyof WaveConfig] as number}
                    onChange={e => set(opKey as keyof WaveConfig, +e.target.value)} className="w-full" />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Preview</label>
            <div className="preview-box rounded-xl overflow-hidden border border-[#1e2d50] bg-[#1a2540]" style={{ minHeight: '180px' }}>
              <div dangerouslySetInnerHTML={{ __html: svgContent.replace(`viewBox="0 0 ${cfg.width} ${cfg.height}"`, `viewBox="0 0 ${cfg.width} ${cfg.height}" preserveAspectRatio="none" width="100%"`) }} />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">SVG Code</label>
            <textarea readOnly value={svgContent} className="code-area rounded-xl p-4 w-full text-xs" rows={12} spellCheck={false} />
          </div>

          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'SVG', ext: 'svg', mime: 'image/svg+xml', content: svgContent },
                { label: 'TXT', ext: 'txt', mime: 'text/plain', content: svgContent },
                { label: 'HTML', ext: 'html', mime: 'text/html', content: `<!DOCTYPE html>\n<html>\n<body style="margin:0">\n${svgContent}\n</body>\n</html>` },
              ]}
              defaultContent={svgContent}
              defaultFilename="wave"
              label="Export SVG"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
