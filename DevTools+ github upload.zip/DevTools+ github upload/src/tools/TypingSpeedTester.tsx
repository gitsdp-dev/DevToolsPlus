import { useState, useEffect, useRef, useCallback } from 'react';
import { Keyboard, RotateCcw, Trophy } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';

const TEXTS = {
  easy: [
    "The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.",
    "A journey of a thousand miles begins with a single step. Keep moving forward every day.",
    "To be or not to be, that is the question. Whether tis nobler in the mind to suffer.",
    "All that glitters is not gold. Often have you heard that told. Many a man his life hath sold.",
  ],
  medium: [
    "JavaScript is a lightweight, interpreted programming language with first-class functions and dynamic typing.",
    "React makes it painless to create interactive UIs. Design simple views for each state in your application.",
    "The World Wide Web was invented by Tim Berners-Lee in 1989. It has transformed how we communicate.",
    "In computer science, recursion is a method of solving problems where the solution depends on smaller instances.",
  ],
  hard: [
    "Asynchronous programming with async/await allows developers to write non-blocking code that's easier to read.",
    "The Byzantine Generals Problem is a fundamental challenge in distributed computing and fault-tolerant systems.",
    "Polymorphism, encapsulation, and inheritance are the three pillars of object-oriented programming paradigms.",
    "Cryptographic hash functions produce a fixed-size output (hash) from variable-size input data deterministically.",
  ],
  code: [
    "const fibonacci = (n) => n <= 1 ? n : fibonacci(n - 1) + fibonacci(n - 2);",
    "function debounce(func, wait) { let timeout; return (...args) => { clearTimeout(timeout); timeout = setTimeout(() => func(...args), wait); }; }",
    "const arr = [1, 2, 3, 4, 5]; const sum = arr.reduce((acc, cur) => acc + cur, 0); console.log(sum);",
    "export default function App() { return <div className='container'><h1>Hello World</h1></div>; }",
  ],
};

type Difficulty = 'easy' | 'medium' | 'hard' | 'code';
type State = 'idle' | 'running' | 'finished';

export default function TypingSpeedTester() {
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [textIndex, setTextIndex] = useState(0);
  const [typed, setTyped] = useState('');
  const [state, setState] = useState<State>('idle');
  const [, setStartTime] = useState<number>(0);
  const [elapsed, setElapsed] = useState(0);
  const [errors, setErrors] = useState(0);
  const [history, setHistory] = useState<{ wpm: number; acc: number; diff: string }[]>([]);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const text = TEXTS[difficulty][textIndex % TEXTS[difficulty].length];

  const stopTimer = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  }, []);

  const startTimer = useCallback(() => {
    stopTimer();
    timerRef.current = setInterval(() => {
      setElapsed(e => e + 0.1);
    }, 100);
  }, [stopTimer]);

  useEffect(() => () => stopTimer(), [stopTimer]);

  const wpm = elapsed > 0 ? Math.round((typed.split(' ').filter(Boolean).length / elapsed) * 60) : 0;
  const accuracy = typed.length > 0
    ? Math.max(0, Math.round(((typed.length - errors) / typed.length) * 100))
    : 100;

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (state === 'finished') return;

    if (state === 'idle') {
      setState('running');
      setStartTime(Date.now());
      startTimer();
    }

    // Count errors
    let errs = 0;
    for (let i = 0; i < val.length; i++) {
      if (val[i] !== text[i]) errs++;
    }
    setErrors(errs);
    setTyped(val);

    if (val.length >= text.length) {
      stopTimer();
      setState('finished');
      const finalWpm = elapsed > 0 ? Math.round((val.split(' ').filter(Boolean).length / elapsed) * 60) : 0;
      const finalAcc = Math.max(0, Math.round(((val.length - errs) / val.length) * 100));
      setHistory(h => [{ wpm: finalWpm, acc: finalAcc, diff: difficulty }, ...h].slice(0, 10));
    }
  };

  const reset = () => {
    stopTimer();
    setTyped('');
    setState('idle');
    setElapsed(0);
    setErrors(0);
    setStartTime(0);
    setTextIndex(i => i + 1);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const handleDiffChange = (d: Difficulty) => {
    setDifficulty(d);
    setTextIndex(0);
    stopTimer();
    setTyped('');
    setState('idle');
    setElapsed(0);
    setErrors(0);
  };

  const renderText = () => {
    return text.split('').map((char, i) => {
      let cls = 'typing-char pending';
      if (i < typed.length) {
        cls = typed[i] === char ? 'typing-char correct' : 'typing-char incorrect';
      } else if (i === typed.length) {
        cls = 'typing-char current';
      }
      return <span key={i} className={cls}>{char}</span>;
    });
  };

  const diffColor = { easy: '#00ff88', medium: '#00d4ff', hard: '#ff4466', code: '#7c3aed' };
  const progress = Math.min(100, (typed.length / text.length) * 100);

  return (
    <ToolLayout
      title="Typing Speed Tester"
      description="Test and improve your typing speed in WPM with accuracy tracking"
      icon={<Keyboard size={20} />}
      badge="WPM Tracker"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex bg-[#060a14] border border-[#1e2d50] rounded-xl p-1 gap-1">
              {(['easy', 'medium', 'hard', 'code'] as Difficulty[]).map(d => (
                <button key={d} onClick={() => handleDiffChange(d)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${difficulty === d ? 'text-white' : 'text-[#64748b]'}`}
                  style={difficulty === d ? { background: diffColor[d] + '33', color: diffColor[d], border: `1px solid ${diffColor[d]}44` } : {}}>
                  {d}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <span className={`text-xs px-3 py-1 rounded-full font-mono ${state === 'running' ? 'bg-[#00ff88]/10 text-[#00ff88]' : state === 'finished' ? 'bg-[#00d4ff]/10 text-[#00d4ff]' : 'bg-[#1e2d50] text-[#64748b]'}`}>
                {state === 'idle' ? 'Ready' : state === 'running' ? '● Recording' : '✓ Complete'}
              </span>
              <button onClick={reset} className="btn-secondary p-2 rounded-xl">
                <RotateCcw size={14} />
              </button>
            </div>
          </div>

          <div className="h-1.5 bg-[#1e2d50] rounded-full overflow-hidden">
            <div className="h-full rounded-full transition-all duration-300"
              style={{ width: `${progress}%`, background: `linear-gradient(90deg, #00d4ff, #7c3aed)` }} />
          </div>

          <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-5">
            <div className="font-mono text-base leading-relaxed select-none" style={{ letterSpacing: '0.05em' }}>
              {renderText()}
            </div>
          </div>

          <div className="relative">
            <textarea
              ref={inputRef}
              value={typed}
              onChange={handleInput}
              disabled={state === 'finished'}
              placeholder={state === 'idle' ? 'Start typing to begin the test...' : ''}
              className={`code-area rounded-xl p-4 w-full resize-none text-sm ${state === 'finished' ? 'opacity-50' : ''}`}
              rows={4}
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
              autoComplete="off"
            />
            {state === 'finished' && (
              <div className="absolute inset-0 flex items-center justify-center bg-[#060a14]/80 rounded-xl">
                <div className="text-center">
                  <Trophy size={32} className="text-[#f59e0b] mx-auto mb-2" />
                  <div className="text-white font-bold text-lg">Test Complete!</div>
                  <button onClick={reset} className="btn-primary px-4 py-2 rounded-xl text-sm mt-2">New Test</button>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'WPM', value: wpm, unit: '', color: '#00d4ff', icon: '⚡' },
              { label: 'Accuracy', value: accuracy, unit: '%', color: accuracy >= 95 ? '#00ff88' : accuracy >= 80 ? '#f59e0b' : '#ff4466', icon: '🎯' },
              { label: 'Time', value: elapsed.toFixed(1), unit: 's', color: '#7c3aed', icon: '⏱' },
              { label: 'Errors', value: errors, unit: '', color: errors === 0 ? '#00ff88' : '#ff4466', icon: '❌' },
            ].map(({ label, value, unit, color, icon }) => (
              <div key={label} className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-3 text-center">
                <div className="text-lg mb-0.5">{icon}</div>
                <div className="text-2xl font-black font-mono" style={{ color }}>{value}{unit}</div>
                <div className="text-xs text-[#64748b] mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4">
            <h3 className="text-sm font-semibold text-[#00d4ff] mb-3 flex items-center gap-2">
              <Trophy size={14} /> Best Scores
            </h3>
            {history.length === 0 ? (
              <p className="text-xs text-[#64748b] text-center py-4">Complete a test to see your scores</p>
            ) : (
              <div className="space-y-2">
                {history.map((h, i) => (
                  <div key={i} className="flex items-center gap-2 py-1.5 border-b border-[#1e2d50] last:border-0">
                    <span className="text-xs text-[#64748b] font-mono w-4">#{i + 1}</span>
                    <span className="text-xs font-mono font-bold text-[#00d4ff]">{h.wpm} WPM</span>
                    <span className="text-xs text-[#64748b]">{h.acc}%</span>
                    <span className="text-xs px-1.5 py-0.5 rounded font-mono ml-auto capitalize"
                      style={{ background: diffColor[h.diff as Difficulty] + '22', color: diffColor[h.diff as Difficulty] }}>
                      {h.diff}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4">
            <h3 className="text-sm font-semibold text-[#7c3aed] mb-3">WPM Scale</h3>
            <div className="space-y-2">
              {[
                { label: 'Beginner', range: '< 30 WPM', color: '#ff4466' },
                { label: 'Average', range: '30–50 WPM', color: '#f59e0b' },
                { label: 'Good', range: '50–70 WPM', color: '#00d4ff' },
                { label: 'Fast', range: '70–100 WPM', color: '#00ff88' },
                { label: 'Expert', range: '100+ WPM', color: '#7c3aed' },
              ].map(({ label, range, color }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                  <span className="text-xs text-[#64748b] flex-1">{label}</span>
                  <span className="text-xs font-mono" style={{ color }}>{range}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4">
            <h3 className="text-sm font-semibold text-[#00ff88] mb-3">Tips</h3>
            <ul className="space-y-1.5">
              {['Keep your eyes on the text, not the keyboard', 'Practice proper finger placement on home row', 'Accuracy over speed — slow down to reduce errors', 'Take breaks to avoid fatigue', 'Consistency beats intensity'].map((tip, i) => (
                <li key={i} className="text-xs text-[#64748b] flex gap-2">
                  <span className="text-[#00ff88]">→</span> {tip}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
