import { useState } from 'react';
import { Database, RefreshCw } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

const FIRST_NAMES = ['Alice','Bob','Charlie','Diana','Ethan','Fiona','George','Hannah','Ivan','Julia','Kevin','Laura','Michael','Nancy','Oscar','Patricia','Quinn','Rachel','Samuel','Taylor','Ulrich','Victoria','Walter','Xena','Yusuf','Zoe'];
const LAST_NAMES = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Wilson','Martinez','Anderson','Taylor','Thomas','Jackson','White','Harris','Lewis','Robinson','Walker','Young'];
const DOMAINS = ['gmail.com','yahoo.com','outlook.com','protonmail.com','example.com','dev.io','techcorp.net'];
const COMPANIES = ['TechCorp','DataSystems','CloudWave','DevForge','ByteWorks','CyberTech','NexusCo','AlphaSoft','QuantumLabs','InnovateTech'];
const JOBS = ['Software Engineer','Frontend Developer','Backend Developer','DevOps Engineer','Product Manager','UX Designer','Data Scientist','System Architect','QA Engineer','Technical Lead'];
const CITIES = ['New York','Los Angeles','London','Tokyo','Paris','Berlin','Sydney','Toronto','Singapore','Dubai','Mumbai','São Paulo','Seoul','Mexico City','Amsterdam'];
const COUNTRIES = ['USA','UK','Japan','France','Germany','Australia','Canada','Singapore','UAE','Brazil','India','South Korea','Mexico','Netherlands','Sweden'];
const STREETS = ['Main St','Oak Ave','Maple Dr','Cedar Ln','Elm Blvd','Pine Rd','Birch Way','Willow Ct','Spruce Pl','Aspen Trail'];
const LOREM = 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'.split(' ');

function rand<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)]; }
function randInt(min: number, max: number): number { return Math.floor(Math.random() * (max - min + 1)) + min; }
function randFloat(min: number, max: number, dec = 2): number { return parseFloat((Math.random() * (max - min) + min).toFixed(dec)); }
function uuid(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}
function phoneNum(): string { return `+1 (${randInt(200, 999)}) ${randInt(200, 999)}-${randInt(1000, 9999)}`; }
function lorem(words: number): string {
  const result: string[] = [];
  for (let i = 0; i < words; i++) result.push(rand(LOREM));
  return result.join(' ');
}
function isoDate(): string {
  const d = new Date(Date.now() - randInt(0, 365 * 5) * 86400000);
  return d.toISOString().split('T')[0];
}
function hexColor(): string {
  return '#' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
}
function ipv4(): string { return Array.from({ length: 4 }, () => randInt(1, 254)).join('.'); }
function mac(): string { return Array.from({ length: 6 }, () => randInt(0, 255).toString(16).padStart(2, '0')).join(':'); }
function creditCard(): string { return `${randInt(4000,4999)} ${randInt(1000,9999)} ${randInt(1000,9999)} ${randInt(1000,9999)}`; }
function url(): string { return `https://${rand(COMPANIES).toLowerCase().replace(' ', '')}.com/${lorem(1)}`; }
function avatar(name: string): string { return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`; }
function username(first: string, last: string): string {
  const opts = [
    `${first.toLowerCase()}${last.toLowerCase()}`,
    `${first.toLowerCase()}.${last.toLowerCase()}`,
    `${first[0].toLowerCase()}${last.toLowerCase()}`,
    `${first.toLowerCase()}${randInt(10, 99)}`,
  ];
  return rand(opts);
}

type FieldType = 'id' | 'uuid' | 'firstName' | 'lastName' | 'fullName' | 'email' | 'phone' | 'company' | 'jobTitle' |
  'age' | 'country' | 'city' | 'address' | 'zipCode' | 'salary' | 'date' | 'boolean' | 'lorem' | 'color' |
  'ipAddress' | 'macAddress' | 'creditCard' | 'url' | 'username' | 'avatar' | 'rating' | 'price';

const FIELD_TYPES: { value: FieldType; label: string }[] = [
  { value: 'id', label: 'ID (number)' }, { value: 'uuid', label: 'UUID' },
  { value: 'firstName', label: 'First Name' }, { value: 'lastName', label: 'Last Name' },
  { value: 'fullName', label: 'Full Name' }, { value: 'email', label: 'Email' },
  { value: 'username', label: 'Username' }, { value: 'phone', label: 'Phone' },
  { value: 'company', label: 'Company' }, { value: 'jobTitle', label: 'Job Title' },
  { value: 'age', label: 'Age' }, { value: 'country', label: 'Country' },
  { value: 'city', label: 'City' }, { value: 'address', label: 'Address' },
  { value: 'zipCode', label: 'Zip Code' }, { value: 'salary', label: 'Salary' },
  { value: 'date', label: 'Date' }, { value: 'boolean', label: 'Boolean' },
  { value: 'lorem', label: 'Lorem Text' }, { value: 'color', label: 'Hex Color' },
  { value: 'ipAddress', label: 'IP Address' }, { value: 'macAddress', label: 'MAC Address' },
  { value: 'creditCard', label: 'Credit Card' }, { value: 'url', label: 'URL' },
  { value: 'avatar', label: 'Avatar URL' }, { value: 'rating', label: 'Rating (1-5)' },
  { value: 'price', label: 'Price' },
];

interface Field { id: number; key: string; type: FieldType; }
let fid = 1;
function newField(key = '', type: FieldType = 'firstName'): Field { return { id: fid++, key, type }; }

function generateValue(type: FieldType, idx: number, context: Record<string, string> = {}): unknown {
  const first = context.firstName || rand(FIRST_NAMES);
  const last = context.lastName || rand(LAST_NAMES);
  switch (type) {
    case 'id': return idx + 1;
    case 'uuid': return uuid();
    case 'firstName': return first;
    case 'lastName': return last;
    case 'fullName': return `${first} ${last}`;
    case 'email': return `${first.toLowerCase()}.${last.toLowerCase()}@${rand(DOMAINS)}`;
    case 'username': return username(first, last);
    case 'phone': return phoneNum();
    case 'company': return rand(COMPANIES);
    case 'jobTitle': return rand(JOBS);
    case 'age': return randInt(18, 70);
    case 'country': return rand(COUNTRIES);
    case 'city': return rand(CITIES);
    case 'address': return `${randInt(1, 999)} ${rand(STREETS)}, Apt ${randInt(1, 99)}`;
    case 'zipCode': return String(randInt(10000, 99999));
    case 'salary': return randInt(30000, 200000);
    case 'date': return isoDate();
    case 'boolean': return Math.random() > 0.5;
    case 'lorem': return lorem(randInt(5, 20));
    case 'color': return hexColor();
    case 'ipAddress': return ipv4();
    case 'macAddress': return mac();
    case 'creditCard': return creditCard();
    case 'url': return url();
    case 'avatar': return avatar(`${first} ${last}`);
    case 'rating': return randFloat(1, 5, 1);
    case 'price': return randFloat(0.99, 999.99, 2);
    default: return '';
  }
}

const DEFAULT_FIELDS: Field[] = [
  newField('id', 'id'),
  newField('name', 'fullName'),
  newField('email', 'email'),
  newField('company', 'company'),
  newField('city', 'city'),
  newField('phone', 'phone'),
];

export default function FakeDataGenerator() {
  const [fields, setFields] = useState<Field[]>(DEFAULT_FIELDS);
  const [count, setCount] = useState(10);
  const [data, setData] = useState<Record<string, unknown>[]>([]);
  const [format, setFormat] = useState<'json' | 'csv' | 'sql' | 'ts'>('json');

  const generate = () => {
    const rows: Record<string, unknown>[] = [];
    for (let i = 0; i < count; i++) {
      const context: Record<string, string> = {};
      const row: Record<string, unknown> = {};
      for (const f of fields) {
        const val = generateValue(f.type, i, context);
        row[f.key || f.type] = val;
        if (f.type === 'firstName') context.firstName = String(val);
        if (f.type === 'lastName') context.lastName = String(val);
      }
      rows.push(row);
    }
    setData(rows);
  };

  const addField = () => setFields(f => [...f, newField('field', 'firstName')]);
  const removeField = (id: number) => setFields(f => f.filter(x => x.id !== id));
  const updateField = (id: number, k: keyof Field, v: string) =>
    setFields(f => f.map(x => x.id === id ? { ...x, [k]: v } : x));

  const getOutput = (): string => {
    if (data.length === 0) return '';
    if (format === 'json') return JSON.stringify(data, null, 2);
    if (format === 'csv') {
      const keys = Object.keys(data[0]);
      const rows = data.map(r => keys.map(k => {
        const v = r[k];
        const s = String(v);
        return s.includes(',') ? `"${s}"` : s;
      }).join(','));
      return [keys.join(','), ...rows].join('\n');
    }
    if (format === 'sql') {
      const table = 'fake_data';
      const keys = Object.keys(data[0]);
      const cols = keys.join(', ');
      const rows = data.map(r => `(${keys.map(k => {
        const v = r[k];
        return typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : String(v);
      }).join(', ')})`).join(',\n  ');
      return `INSERT INTO ${table} (${cols}) VALUES\n  ${rows};`;
    }
    if (format === 'ts') {
      const keys = Object.keys(data[0]);
      const typeLines = keys.map(k => {
        const sample = data[0][k];
        const t = typeof sample === 'number' ? 'number' : typeof sample === 'boolean' ? 'boolean' : 'string';
        return `  ${k}: ${t};`;
      });
      return `interface DataRecord {\n${typeLines.join('\n')}\n}\n\nconst records: DataRecord[] = ${JSON.stringify(data, null, 2)};`;
    }
    return '';
  };

  const output = getOutput();
  const mimeMap = { json: 'application/json', csv: 'text/csv', sql: 'text/plain', ts: 'application/typescript' };
  const extMap = { json: 'json', csv: 'csv', sql: 'sql', ts: 'ts' };

  return (
    <ToolLayout
      title="Fake Data Generator"
      description="Generate realistic fake data for testing and development"
      icon={<Database size={20} />}
      badge="Multi-Format"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#64748b] font-mono uppercase tracking-wider">Record Count</span>
              <span className="text-[#00d4ff] font-mono">{count}</span>
            </div>
            <input type="range" min="1" max="500" value={count} onChange={e => setCount(+e.target.value)} className="w-full" />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Fields</label>
              <button onClick={addField} className="text-xs text-[#00d4ff] hover:text-white transition-colors">+ Add</button>
            </div>
            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {fields.map(f => (
                <div key={f.id} className="flex gap-2 items-center">
                  <input
                    value={f.key}
                    onChange={e => updateField(f.id, 'key', e.target.value)}
                    className="input-field flex-1 px-2 py-1.5 rounded-lg text-xs font-mono"
                    placeholder="field name"
                  />
                  <select
                    value={f.type}
                    onChange={e => updateField(f.id, 'type', e.target.value)}
                    className="input-field flex-1 px-2 py-1.5 rounded-lg text-xs"
                  >
                    {FIELD_TYPES.map(ft => <option key={ft.value} value={ft.value}>{ft.label}</option>)}
                  </select>
                  <button onClick={() => removeField(f.id)} className="text-[#ff4466] hover:text-red-300 px-1">×</button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Export Format</label>
            <div className="grid grid-cols-4 gap-1">
              {(['json', 'csv', 'sql', 'ts'] as const).map(f => (
                <button key={f} onClick={() => setFormat(f)}
                  className={`py-2 rounded-lg text-xs font-semibold uppercase transition-all ${format === f ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>

          <button onClick={generate} className="btn-green w-full py-3 rounded-xl text-sm flex items-center justify-center gap-2">
            <RefreshCw size={15} /> Generate {count} Records
          </button>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-4">
          {data.length > 0 && format === 'json' && (
            <div className="overflow-x-auto rounded-xl border border-[#1e2d50]">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#0f1629] border-b border-[#1e2d50]">
                    {Object.keys(data[0]).map(k => (
                      <th key={k} className="px-3 py-2 text-left font-mono text-[#00d4ff] whitespace-nowrap">{k}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.slice(0, 8).map((row, i) => (
                    <tr key={i} className="border-b border-[#1e2d50] hover:bg-[#0f1629] transition-colors">
                      {Object.values(row).map((v, j) => (
                        <td key={j} className="px-3 py-2 font-mono text-[#64748b] max-w-[200px] truncate" title={String(v)}>
                          {typeof v === 'boolean' ? (v ? '✓' : '✗') : String(v)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {data.length > 8 && (
                <div className="text-center text-xs text-[#64748b] py-2 border-t border-[#1e2d50]">
                  + {data.length - 8} more records in export
                </div>
              )}
            </div>
          )}

          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">
                Output ({format.toUpperCase()})
              </label>
              {data.length > 0 && (
                <span className="text-xs text-[#64748b] font-mono">{data.length} records • {output.length.toLocaleString()} chars</span>
              )}
            </div>
            <textarea
              readOnly
              value={output || 'Click "Generate" to create fake data...'}
              className="code-area rounded-xl p-4 w-full text-xs"
              rows={data.length > 0 ? 20 : 8}
              spellCheck={false}
            />
          </div>

          {data.length > 0 && (
            <div className="flex justify-end">
              <ExportButton
                formats={[
                  { label: format.toUpperCase(), ext: extMap[format], mime: mimeMap[format], content: output },
                  { label: 'JSON', ext: 'json', mime: 'application/json', content: JSON.stringify(data, null, 2) },
                  { label: 'CSV', ext: 'csv', mime: 'text/csv', content: (() => {
                    const keys = Object.keys(data[0]);
                    return [keys.join(','), ...data.map(r => keys.map(k => String(r[k])).join(','))].join('\n');
                  })() },
                ]}
                defaultContent={output}
                defaultFilename={`fake-data-${count}`}
                label="Export Data"
              />
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
}
