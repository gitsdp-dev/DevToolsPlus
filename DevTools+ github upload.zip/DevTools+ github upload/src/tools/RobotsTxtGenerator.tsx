import { useState } from 'react';
import { Bot, Plus, Trash2 } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

interface RobotsRule {
  id: number;
  userAgent: string;
  allow: string[];
  disallow: string[];
  crawlDelay: string;
}

let ruleId = 1;
function newRule(): RobotsRule {
  return { id: ruleId++, userAgent: '*', allow: ['/'], disallow: ['/admin/', '/private/'], crawlDelay: '' };
}

export default function RobotsTxtGenerator() {
  const [rules, setRules] = useState<RobotsRule[]>([newRule()]);
  const [sitemapUrl, setSitemapUrl] = useState('https://example.com/sitemap.xml');
  const [host, setHost] = useState('https://example.com');
  const [selectedRule, setSelectedRule] = useState(0);

  const updateRule = (id: number, k: keyof RobotsRule, v: unknown) =>
    setRules(r => r.map(rule => rule.id === id ? { ...rule, [k]: v } : rule));

  const addPath = (id: number, type: 'allow' | 'disallow') => {
    setRules(r => r.map(rule => rule.id === id ? { ...rule, [type]: [...rule[type], '/'] } : rule));
  };

  const removePath = (id: number, type: 'allow' | 'disallow', idx: number) => {
    setRules(r => r.map(rule => rule.id === id ? { ...rule, [type]: rule[type].filter((_, i) => i !== idx) } : rule));
  };

  const updatePath = (id: number, type: 'allow' | 'disallow', idx: number, val: string) => {
    setRules(r => r.map(rule => rule.id === id ? {
      ...rule, [type]: rule[type].map((p, i) => i === idx ? val : p)
    } : rule));
  };

  const generateRobots = (): string => {
    const sections = rules.map(rule => {
      const lines = [`User-agent: ${rule.userAgent}`];
      rule.allow.forEach(p => p && lines.push(`Allow: ${p}`));
      rule.disallow.forEach(p => p && lines.push(`Disallow: ${p}`));
      if (rule.crawlDelay) lines.push(`Crawl-delay: ${rule.crawlDelay}`);
      return lines.join('\n');
    });
    const extras: string[] = [];
    if (host) extras.push(`Host: ${host}`);
    if (sitemapUrl) extras.push(`Sitemap: ${sitemapUrl}`);
    return [...sections, ...(extras.length ? ['', ...extras] : [])].join('\n\n');
  };

  const output = generateRobots();
  const rule = rules[selectedRule] || rules[0];

  const PRESETS = [
    { label: 'Allow All', userAgent: '*', allow: ['/'], disallow: [] },
    { label: 'Block All', userAgent: '*', allow: [], disallow: ['/'] },
    { label: 'Block Bots', userAgent: 'Googlebot', allow: ['/'], disallow: ['/admin/', '/api/'] },
    { label: 'SEO Friendly', userAgent: '*', allow: ['/'], disallow: ['/admin/', '/cart/', '/checkout/', '/*.json'] },
  ];

  return (
    <ToolLayout
      title="Robots.txt Generator"
      description="Generate robots.txt files to control search engine crawling"
      icon={<Bot size={20} />}
      badge="SEO"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Quick Presets</label>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map(preset => (
                <button key={preset.label} onClick={() => {
                  const nr = { ...newRule(), ...preset, id: rules[selectedRule]?.id || ruleId };
                  setRules(r => r.map((ru, i) => i === selectedRule ? nr : ru));
                }}
                  className="btn-secondary py-2 px-3 rounded-xl text-xs text-left">
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Rules</label>
              <button onClick={() => { const nr = newRule(); setRules(r => [...r, nr]); setSelectedRule(rules.length); }}
                className="text-xs text-[#00d4ff] hover:text-white transition-colors flex items-center gap-1">
                <Plus size={12} /> Add Rule
              </button>
            </div>
            <div className="space-y-1">
              {rules.map((r, i) => (
                <div key={r.id} onClick={() => setSelectedRule(i)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-all ${i === selectedRule ? 'bg-[#1e2d50] border border-[#00d4ff]/30' : 'bg-[#060a14] border border-[#1e2d50]'}`}>
                  <Bot size={12} className="text-[#00d4ff]" />
                  <span className="text-xs font-mono flex-1">User-agent: {r.userAgent}</span>
                  {rules.length > 1 && (
                    <button onClick={e => { e.stopPropagation(); setRules(r => r.filter((_, j) => j !== i)); setSelectedRule(0); }}
                      className="text-[#ff4466] hover:text-red-300">
                      <Trash2 size={12} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {rule && (
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 space-y-4">
              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">User-Agent</label>
                <input value={rule.userAgent} onChange={e => updateRule(rule.id, 'userAgent', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder="*" />
                <div className="flex flex-wrap gap-1 mt-1">
                  {['*', 'Googlebot', 'Bingbot', 'facebookexternalhit', 'Twitterbot'].map(ua => (
                    <button key={ua} onClick={() => updateRule(rule.id, 'userAgent', ua)}
                      className="text-xs px-2 py-0.5 rounded bg-[#1e2d50] text-[#64748b] hover:text-white transition-colors">{ua}</button>
                  ))}
                </div>
              </div>

              {(['allow', 'disallow'] as const).map(type => (
                <div key={type}>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-mono uppercase tracking-wider" style={{ color: type === 'allow' ? '#00ff88' : '#ff4466' }}>
                      {type}
                    </label>
                    <button onClick={() => addPath(rule.id, type)} className="text-xs text-[#00d4ff] hover:text-white flex items-center gap-1">
                      <Plus size={10} /> Add
                    </button>
                  </div>
                  <div className="space-y-1">
                    {rule[type].map((path, i) => (
                      <div key={i} className="flex gap-2">
                        <input value={path} onChange={e => updatePath(rule.id, type, i, e.target.value)}
                          className="input-field flex-1 px-3 py-1.5 rounded-lg text-sm font-mono" placeholder="/path/" />
                        <button onClick={() => removePath(rule.id, type, i)} className="text-[#ff4466] hover:text-red-300 px-2">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ))}
                    {rule[type].length === 0 && (
                      <div className="text-xs text-[#64748b] italic py-1">No paths added</div>
                    )}
                  </div>
                </div>
              ))}

              <div>
                <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Crawl Delay (optional)</label>
                <input type="number" min="0" value={rule.crawlDelay}
                  onChange={e => updateRule(rule.id, 'crawlDelay', e.target.value)}
                  className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder="10" />
              </div>
            </div>
          )}

          <div className="space-y-3">
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Sitemap URL</label>
              <input value={sitemapUrl} onChange={e => setSitemapUrl(e.target.value)}
                className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder="https://example.com/sitemap.xml" />
            </div>
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Host (optional)</label>
              <input value={host} onChange={e => setHost(e.target.value)}
                className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder="https://example.com" />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Generated robots.txt</label>
          </div>
          <textarea readOnly value={output} className="code-area rounded-xl p-4 w-full text-sm flex-1" rows={28} spellCheck={false} />
          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'TXT', ext: 'txt', mime: 'text/plain', content: output },
                { label: 'robots.txt', ext: 'txt', mime: 'text/plain', content: output },
              ]}
              defaultContent={output}
              defaultFilename="robots"
              label="Export"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
