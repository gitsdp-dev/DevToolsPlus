import { useState, useCallback } from 'react';
import { Code2, AlertCircle, CheckCircle, Minimize2, Maximize2 } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

export default function JsonFormatter() {
  const [input, setInput] = useState('{\n  "name": "DevTools+",\n  "version": "1.0.0",\n  "features": ["JSON Formatter", "Code Beautifier"],\n  "awesome": true\n}');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');
  const [indent, setIndent] = useState(2);
  const [sortKeys, setSortKeys] = useState(false);

  const sortObject = (obj: unknown): unknown => {
    if (Array.isArray(obj)) return obj.map(sortObject);
    if (obj !== null && typeof obj === 'object') {
      return Object.keys(obj as Record<string, unknown>).sort().reduce((acc: Record<string, unknown>, k) => {
        acc[k] = sortObject((obj as Record<string, unknown>)[k]);
        return acc;
      }, {});
    }
    return obj;
  };

  const format = useCallback(() => {
    try {
      let parsed = JSON.parse(input);
      if (sortKeys) parsed = sortObject(parsed);
      setOutput(JSON.stringify(parsed, null, indent));
      setError('');
    } catch (e: unknown) {
      setError((e as Error).message);
      setOutput('');
    }
  }, [input, indent, sortKeys]);

  const minify = useCallback(() => {
    try {
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed));
      setError('');
    } catch (e: unknown) {
      setError((e as Error).message);
      setOutput('');
    }
  }, [input]);

  const validate = useCallback(() => {
    try {
      JSON.parse(input);
      setError('');
      setOutput('✓ Valid JSON');
    } catch (e: unknown) {
      setError((e as Error).message);
      setOutput('');
    }
  }, [input]);

  const isValid = (() => {
    try { JSON.parse(input); return true; } catch { return false; }
  })();

  return (
    <ToolLayout
      title="JSON Formatter"
      description="Format, validate, minify and analyze JSON data"
      icon={<Code2 size={20} />}
      badge="Validator"
    >
      <div className="flex gap-3 mb-4 flex-wrap items-center">
        <div className="flex items-center gap-2 text-sm">
          <label className="text-[#64748b]">Indent:</label>
          <select
            value={indent}
            onChange={e => setIndent(+e.target.value)}
            className="input-field px-2 py-1 rounded-lg text-sm w-16"
          >
            {[2, 4, 6, 8].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <label className="flex items-center gap-2 text-sm text-[#64748b] cursor-pointer">
          <input type="checkbox" checked={sortKeys} onChange={e => setSortKeys(e.target.checked)} className="rounded" />
          Sort Keys
        </label>
        <div className="flex items-center gap-2 ml-auto">
          <span className={`flex items-center gap-1.5 text-xs font-mono px-3 py-1 rounded-full border ${isValid ? 'text-[#00ff88] border-[#00ff88]/30 bg-[#00ff88]/10' : 'text-[#ff4466] border-[#ff4466]/30 bg-[#ff4466]/10'}`}>
            {isValid ? <CheckCircle size={12} /> : <AlertCircle size={12} />}
            {isValid ? 'Valid JSON' : 'Invalid JSON'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Input JSON</label>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            className="code-area rounded-xl p-4 min-h-[380px] w-full"
            placeholder='Paste your JSON here...'
            spellCheck={false}
          />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Output</label>
          <div className="relative">
            <textarea
              readOnly
              value={error ? `Error: ${error}` : output}
              className={`code-area rounded-xl p-4 min-h-[380px] w-full ${error ? 'text-[#ff4466]' : ''}`}
              placeholder='Formatted output will appear here...'
              spellCheck={false}
            />
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-3 mt-4 items-center">
        <button onClick={format} className="btn-primary px-5 py-2 rounded-xl text-sm flex items-center gap-2">
          <Maximize2 size={14} /> Format
        </button>
        <button onClick={minify} className="btn-secondary px-5 py-2 rounded-xl text-sm flex items-center gap-2">
          <Minimize2 size={14} /> Minify
        </button>
        <button onClick={validate} className="btn-secondary px-5 py-2 rounded-xl text-sm flex items-center gap-2">
          <CheckCircle size={14} /> Validate
        </button>
        <div className="ml-auto">
          <ExportButton
            formats={[
              { label: 'JSON', ext: 'json', mime: 'application/json' },
              { label: 'TXT', ext: 'txt', mime: 'text/plain' },
            ]}
            defaultContent={output || input}
            defaultFilename="formatted"
            label="Export"
          />
        </div>
      </div>
    </ToolLayout>
  );
}
