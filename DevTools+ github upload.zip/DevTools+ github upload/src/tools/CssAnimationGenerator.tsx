import { useState } from 'react';
import { Zap } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

type AnimType = 'fade' | 'slide' | 'bounce' | 'spin' | 'pulse' | 'shake' | 'flip' | 'zoom' | 'swing';

interface AnimConfig {
  type: AnimType;
  duration: number;
  delay: number;
  easing: string;
  iteration: string;
  direction: string;
  fillMode: string;
}

const EASINGS = ['ease', 'ease-in', 'ease-out', 'ease-in-out', 'linear', 'cubic-bezier(0.68,-0.55,0.27,1.55)'];
const ITERATIONS = ['1', '2', '3', 'infinite'];
const DIRECTIONS = ['normal', 'reverse', 'alternate', 'alternate-reverse'];
const FILL_MODES = ['none', 'forwards', 'backwards', 'both'];
const ANIM_TYPES: AnimType[] = ['fade', 'slide', 'bounce', 'spin', 'pulse', 'shake', 'flip', 'zoom', 'swing'];

const KEYFRAMES: Record<AnimType, string> = {
  fade: `@keyframes devtools-fade {
  from { opacity: 0; }
  to { opacity: 1; }
}`,
  slide: `@keyframes devtools-slide {
  from { transform: translateX(-60px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}`,
  bounce: `@keyframes devtools-bounce {
  0%, 100% { transform: translateY(0); animation-timing-function: ease-in; }
  50% { transform: translateY(-30px); animation-timing-function: ease-out; }
}`,
  spin: `@keyframes devtools-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}`,
  pulse: `@keyframes devtools-pulse {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.15); opacity: 0.7; }
}`,
  shake: `@keyframes devtools-shake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-10px); }
  40% { transform: translateX(10px); }
  60% { transform: translateX(-8px); }
  80% { transform: translateX(8px); }
}`,
  flip: `@keyframes devtools-flip {
  0% { transform: perspective(400px) rotateY(0); }
  40% { transform: perspective(400px) rotateY(-180deg); }
  100% { transform: perspective(400px) rotateY(-360deg); }
}`,
  zoom: `@keyframes devtools-zoom {
  from { transform: scale(0); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}`,
  swing: `@keyframes devtools-swing {
  20% { transform: rotate(15deg); }
  40% { transform: rotate(-10deg); }
  60% { transform: rotate(5deg); }
  80% { transform: rotate(-5deg); }
  100% { transform: rotate(0deg); }
}`,
};

function generateCSS(cfg: AnimConfig): string {
  const kf = KEYFRAMES[cfg.type];
  const cls = `.animated-element {
  animation-name: devtools-${cfg.type};
  animation-duration: ${cfg.duration}s;
  animation-delay: ${cfg.delay}s;
  animation-timing-function: ${cfg.easing};
  animation-iteration-count: ${cfg.iteration};
  animation-direction: ${cfg.direction};
  animation-fill-mode: ${cfg.fillMode};
}`;
  return `${kf}\n\n${cls}`;
}

export default function CssAnimationGenerator() {
  const [cfg, setCfg] = useState<AnimConfig>({
    type: 'fade', duration: 1, delay: 0, easing: 'ease-in-out',
    iteration: '1', direction: 'normal', fillMode: 'forwards',
  });
  const [previewKey, setPreviewKey] = useState(0);
  const [previewBg, setPreviewBg] = useState('#00d4ff');

  const css = generateCSS(cfg);
  const set = (k: keyof AnimConfig, v: string | number) => setCfg(p => ({ ...p, [k]: v }));

  const triggerPreview = () => setPreviewKey(k => k + 1);

  const previewStyle = {
    animationName: `devtools-${cfg.type}`,
    animationDuration: `${cfg.duration}s`,
    animationDelay: `${cfg.delay}s`,
    animationTimingFunction: cfg.easing,
    animationIterationCount: cfg.iteration,
    animationDirection: cfg.direction as 'normal',
    animationFillMode: cfg.fillMode as 'forwards',
  };

  const keyframesCss = Object.entries(KEYFRAMES).map(([, v]) => v).join('\n');

  return (
    <ToolLayout
      title="CSS Animation Generator"
      description="Create and preview custom CSS animations with live preview"
      icon={<Zap size={20} />}
      badge="Live Preview"
    >
      <style>{keyframesCss}</style>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Animation Type</label>
            <div className="grid grid-cols-3 gap-1.5">
              {ANIM_TYPES.map(t => (
                <button
                  key={t}
                  onClick={() => set('type', t)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-semibold capitalize transition-all ${cfg.type === t ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Duration: {cfg.duration}s</label>
            <input type="range" min="0.1" max="5" step="0.1" value={cfg.duration}
              onChange={e => set('duration', +e.target.value)} className="w-full" />
          </div>
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Delay: {cfg.delay}s</label>
            <input type="range" min="0" max="3" step="0.1" value={cfg.delay}
              onChange={e => set('delay', +e.target.value)} className="w-full" />
          </div>

          {[
            { label: 'Easing', key: 'easing', opts: EASINGS },
            { label: 'Iteration', key: 'iteration', opts: ITERATIONS },
            { label: 'Direction', key: 'direction', opts: DIRECTIONS },
            { label: 'Fill Mode', key: 'fillMode', opts: FILL_MODES },
          ].map(({ label, key, opts }) => (
            <div key={key}>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">{label}</label>
              <select
                value={cfg[key as keyof AnimConfig]}
                onChange={e => set(key as keyof AnimConfig, e.target.value)}
                className="input-field w-full px-3 py-2 rounded-xl text-sm"
              >
                {opts.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          ))}

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Preview Color</label>
            <div className="flex gap-2 flex-wrap">
              {['#00d4ff', '#7c3aed', '#00ff88', '#ff4466', '#f59e0b'].map(c => (
                <button key={c} onClick={() => setPreviewBg(c)}
                  className={`w-8 h-8 rounded-lg border-2 transition-transform ${previewBg === c ? 'border-white scale-110' : 'border-transparent'}`}
                  style={{ background: c }} />
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Live Preview</label>
              <button onClick={triggerPreview} className="btn-primary px-3 py-1 rounded-lg text-xs flex items-center gap-1">
                <Zap size={12} /> Replay
              </button>
            </div>
            <div className="preview-box rounded-xl h-52 flex items-center justify-center border border-[#1e2d50]">
              <div
                key={previewKey}
                style={{ ...previewStyle, background: previewBg }}
                className="w-20 h-20 rounded-2xl shadow-2xl flex items-center justify-center text-white font-bold text-sm"
              >
                DEV+
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Generated CSS</label>
            <textarea readOnly value={css} className="code-area rounded-xl p-4 w-full text-xs" rows={16} spellCheck={false} />
          </div>

          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'CSS', ext: 'css', mime: 'text/css' },
                { label: 'TXT', ext: 'txt', mime: 'text/plain' },
              ]}
              defaultContent={css}
              defaultFilename="animation"
              label="Export CSS"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
