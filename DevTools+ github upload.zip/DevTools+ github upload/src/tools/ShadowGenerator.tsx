import { useState } from 'react';
import { Layers } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

interface Shadow {
  id: number;
  x: number;
  y: number;
  blur: number;
  spread: number;
  color: string;
  opacity: number;
  inset: boolean;
}

let idCounter = 1;
function newShadow(): Shadow {
  return { id: idCounter++, x: 4, y: 8, blur: 24, spread: 0, color: '#00d4ff', opacity: 30, inset: false };
}

export default function ShadowGenerator() {
  const [shadows, setShadows] = useState<Shadow[]>([newShadow()]);
  const [selected, setSelected] = useState(0);
  const [boxBg, setBoxBg] = useState('#7c3aed');
  const [cardBg, setCardBg] = useState('#1a2540');
  const [shadowType, setShadowType] = useState<'box' | 'text' | 'drop'>('box');

  const update = (id: number, k: keyof Shadow, v: unknown) => {
    setShadows(s => s.map(sh => sh.id === id ? { ...sh, [k]: v } : sh));
  };

  const hexToRgba = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${alpha / 100})`;
  };

  const shadowStr = shadows.map(s =>
    `${s.inset ? 'inset ' : ''}${s.x}px ${s.y}px ${s.blur}px ${s.spread}px ${hexToRgba(s.color, s.opacity)}`
  ).join(', ');

  const getCSSValue = () => {
    if (shadowType === 'box') return shadowStr;
    if (shadowType === 'text') return shadows.map(s => `${s.x}px ${s.y}px ${s.blur}px ${hexToRgba(s.color, s.opacity)}`).join(', ');
    return `drop-shadow(${shadows[0].x}px ${shadows[0].y}px ${shadows[0].blur}px ${hexToRgba(shadows[0].color, shadows[0].opacity)})`;
  };

  const cssProp = shadowType === 'box' ? 'box-shadow' : shadowType === 'text' ? 'text-shadow' : 'filter';
  const cssOutput = `.element {\n  ${cssProp}: ${getCSSValue()};\n}`;

  const previewStyle = shadowType === 'box'
    ? { boxShadow: getCSSValue() }
    : shadowType === 'text'
    ? { textShadow: getCSSValue() }
    : { filter: getCSSValue() };

  const sh = shadows[selected] || shadows[0];

  return (
    <ToolLayout
      title="Shadow Generator"
      description="Generate box shadows, text shadows, and drop filters visually"
      icon={<Layers size={20} />}
      badge="Visual Editor"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div className="flex gap-1 bg-[#060a14] border border-[#1e2d50] rounded-xl p-1">
            {(['box', 'text', 'drop'] as const).map(t => (
              <button key={t} onClick={() => setShadowType(t)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${shadowType === t ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'text-[#64748b]'}`}>
                {t === 'box' ? 'Box Shadow' : t === 'text' ? 'Text Shadow' : 'Drop Filter'}
              </button>
            ))}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Layers</label>
              {shadowType !== 'drop' && (
                <button onClick={() => { const ns = newShadow(); setShadows(s => [...s, ns]); setSelected(shadows.length); }}
                  className="text-xs text-[#00d4ff] hover:text-white transition-colors">+ Add Layer</button>
              )}
            </div>
            <div className="space-y-1">
              {shadows.map((s, i) => (
                <div key={s.id} onClick={() => setSelected(i)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-all ${i === selected ? 'bg-[#1e2d50] border border-[#00d4ff]/30' : 'bg-[#060a14] border border-[#1e2d50] hover:border-[#1e2d50]'}`}>
                  <div className="w-4 h-4 rounded" style={{ background: s.color, opacity: s.opacity / 100 }} />
                  <span className="text-xs text-[#64748b] font-mono flex-1">Layer {i + 1} {s.inset ? '(inset)' : ''}</span>
                  {shadows.length > 1 && (
                    <button onClick={e => { e.stopPropagation(); setShadows(s => s.filter((_, j) => j !== i)); setSelected(0); }}
                      className="text-[#ff4466] text-xs hover:text-red-300">×</button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {sh && (
            <div className="space-y-3">
              {[
                { label: 'X Offset', key: 'x', min: -100, max: 100 },
                { label: 'Y Offset', key: 'y', min: -100, max: 100 },
                { label: 'Blur', key: 'blur', min: 0, max: 150 },
                ...(shadowType === 'box' ? [{ label: 'Spread', key: 'spread', min: -50, max: 100 }] : []),
                { label: 'Opacity %', key: 'opacity', min: 0, max: 100 },
              ].map(({ label, key, min, max }) => (
                <div key={key}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#64748b] font-mono uppercase tracking-wider">{label}</span>
                    <span className="text-[#00d4ff] font-mono">{sh[key as keyof Shadow]}</span>
                  </div>
                  <input type="range" min={min} max={max} value={sh[key as keyof Shadow] as number}
                    onChange={e => update(sh.id, key as keyof Shadow, +e.target.value)} className="w-full" />
                </div>
              ))}

              <div className="flex items-center gap-3">
                <div>
                  <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Color</label>
                  <input type="color" value={sh.color} onChange={e => update(sh.id, 'color', e.target.value)}
                    className="w-12 h-10 rounded-lg border border-[#1e2d50] cursor-pointer bg-transparent" />
                </div>
                {shadowType === 'box' && (
                  <label className="flex items-center gap-2 text-sm text-[#64748b] cursor-pointer mt-4">
                    <input type="checkbox" checked={sh.inset} onChange={e => update(sh.id, 'inset', e.target.checked)} />
                    Inset
                  </label>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Element Color</label>
              <input type="color" value={boxBg} onChange={e => setBoxBg(e.target.value)}
                className="w-full h-10 rounded-lg border border-[#1e2d50] cursor-pointer bg-transparent" />
            </div>
            <div>
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Canvas Color</label>
              <input type="color" value={cardBg} onChange={e => setCardBg(e.target.value)}
                className="w-full h-10 rounded-lg border border-[#1e2d50] cursor-pointer bg-transparent" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Preview</label>
            <div className="rounded-xl h-56 flex items-center justify-center border border-[#1e2d50] transition-all" style={{ background: cardBg }}>
              {shadowType === 'text' ? (
                <span className="text-5xl font-black" style={{ color: boxBg, ...previewStyle }}>Dev+</span>
              ) : (
                <div className="w-32 h-32 rounded-2xl flex items-center justify-center font-bold text-white"
                  style={{ background: boxBg, ...previewStyle }}>
                  <Layers size={32} />
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">Generated CSS</label>
            <textarea readOnly value={cssOutput} className="code-area rounded-xl p-4 w-full text-sm" rows={6} spellCheck={false} />
          </div>

          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'CSS', ext: 'css', mime: 'text/css' },
                { label: 'TXT', ext: 'txt', mime: 'text/plain' },
              ]}
              defaultContent={cssOutput}
              defaultFilename="shadow"
              label="Export CSS"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
