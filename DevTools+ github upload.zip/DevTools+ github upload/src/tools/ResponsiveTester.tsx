import { useState } from 'react';
import { Monitor, Smartphone, Tablet, Globe, RotateCcw } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';

interface Device {
  name: string;
  width: number;
  height: number;
  icon: React.ReactNode;
  category: 'mobile' | 'tablet' | 'desktop';
}

const DEVICES: Device[] = [
  { name: 'iPhone SE', width: 375, height: 667, icon: <Smartphone size={14} />, category: 'mobile' },
  { name: 'iPhone 14', width: 390, height: 844, icon: <Smartphone size={14} />, category: 'mobile' },
  { name: 'iPhone 14 Pro Max', width: 430, height: 932, icon: <Smartphone size={14} />, category: 'mobile' },
  { name: 'Samsung S21', width: 360, height: 800, icon: <Smartphone size={14} />, category: 'mobile' },
  { name: 'Pixel 7', width: 412, height: 915, icon: <Smartphone size={14} />, category: 'mobile' },
  { name: 'iPad Mini', width: 768, height: 1024, icon: <Tablet size={14} />, category: 'tablet' },
  { name: 'iPad Air', width: 820, height: 1180, icon: <Tablet size={14} />, category: 'tablet' },
  { name: 'iPad Pro 12.9"', width: 1024, height: 1366, icon: <Tablet size={14} />, category: 'tablet' },
  { name: 'Surface Pro', width: 912, height: 1368, icon: <Tablet size={14} />, category: 'tablet' },
  { name: 'Laptop HD', width: 1280, height: 800, icon: <Monitor size={14} />, category: 'desktop' },
  { name: 'Full HD', width: 1920, height: 1080, icon: <Monitor size={14} />, category: 'desktop' },
  { name: 'MacBook Pro', width: 1440, height: 900, icon: <Monitor size={14} />, category: 'desktop' },
  { name: '4K Display', width: 2560, height: 1440, icon: <Monitor size={14} />, category: 'desktop' },
];

export default function ResponsiveTester() {
  const [url, setUrl] = useState('https://example.com');
  const [inputUrl, setInputUrl] = useState('https://example.com');
  const [selected, setSelected] = useState(0);
  const [rotated, setRotated] = useState(false);
  const [customW, setCustomW] = useState(800);
  const [customH, setCustomH] = useState(600);
  const [useCustom, setUseCustom] = useState(false);
  const [filter, setFilter] = useState<'all' | 'mobile' | 'tablet' | 'desktop'>('all');

  const device = useCustom
    ? { name: 'Custom', width: customW, height: customH, icon: <Monitor size={14} />, category: 'desktop' as const }
    : DEVICES[selected];

  const w = rotated ? device.height : device.width;
  const h = rotated ? device.width : device.height;

  const MAX_W = 900;
  const MAX_H = 500;
  const scale = Math.min(MAX_W / w, MAX_H / h, 1);

  const filteredDevices = DEVICES.filter(d => filter === 'all' || d.category === filter);

  const catColor = (cat: string) => cat === 'mobile' ? '#00ff88' : cat === 'tablet' ? '#00d4ff' : '#7c3aed';

  return (
    <ToolLayout
      title="Responsive Tester"
      description="Preview your website on different screen sizes and devices"
      icon={<Monitor size={20} />}
      badge="Multi-Device"
    >
      <div className="flex flex-col gap-4">
        <div className="flex gap-3 flex-wrap items-center">
          <input
            value={inputUrl}
            onChange={e => setInputUrl(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && setUrl(inputUrl)}
            className="input-field flex-1 min-w-[200px] px-4 py-2.5 rounded-xl text-sm"
            placeholder="https://example.com"
          />
          <button onClick={() => setUrl(inputUrl)} className="btn-primary px-5 py-2.5 rounded-xl text-sm flex items-center gap-2">
            <Globe size={14} /> Load
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="space-y-3">
            <div className="flex gap-1 flex-wrap">
              {(['all', 'mobile', 'tablet', 'desktop'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-3 py-1 rounded-lg text-xs capitalize transition-all ${filter === f ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                  {f}
                </button>
              ))}
            </div>

            <div className="space-y-1 max-h-64 overflow-y-auto pr-1">
              {filteredDevices.map((d) => {
                const origIdx = DEVICES.indexOf(d);
                return (
                  <button key={d.name} onClick={() => { setSelected(origIdx); setUseCustom(false); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-xs transition-all ${!useCustom && selected === origIdx ? 'bg-[#1e2d50] border border-[#00d4ff]/30 text-white' : 'bg-[#060a14] border border-[#1e2d50] text-[#64748b] hover:border-[#1e2d50]'}`}>
                    <span style={{ color: catColor(d.category) }}>{d.icon}</span>
                    <div className="flex-1">
                      <div className="font-medium" style={{ color: !useCustom && selected === origIdx ? '#fff' : undefined }}>{d.name}</div>
                      <div className="text-[10px] text-[#64748b] font-mono">{d.width}×{d.height}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-3 space-y-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block">Custom Size</label>
              <div className="flex gap-2 items-center">
                <input type="number" min="100" max="3000" value={customW}
                  onChange={e => { setCustomW(+e.target.value); setUseCustom(true); }}
                  className="input-field flex-1 px-2 py-1.5 rounded-lg text-xs font-mono" placeholder="Width" />
                <span className="text-[#64748b] text-xs">×</span>
                <input type="number" min="100" max="3000" value={customH}
                  onChange={e => { setCustomH(+e.target.value); setUseCustom(true); }}
                  className="input-field flex-1 px-2 py-1.5 rounded-lg text-xs font-mono" placeholder="Height" />
              </div>
              <button onClick={() => setUseCustom(true)}
                className={`w-full py-1.5 rounded-lg text-xs transition-all ${useCustom ? 'bg-gradient-to-r from-[#00d4ff] to-[#7c3aed] text-white' : 'btn-secondary'}`}>
                Use Custom
              </button>
            </div>

            <button onClick={() => setRotated(r => !r)}
              className="btn-secondary w-full py-2 rounded-xl text-sm flex items-center justify-center gap-2">
              <RotateCcw size={14} /> Rotate {rotated ? '(Portrait)' : '(Landscape)'}
            </button>

            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-3">
              <div className="text-xs text-[#64748b] font-mono uppercase tracking-wider mb-2">Info</div>
              <div className="space-y-1">
                {[
                  { label: 'Device', value: device.name },
                  { label: 'Width', value: `${w}px` },
                  { label: 'Height', value: `${h}px` },
                  { label: 'Scale', value: `${(scale * 100).toFixed(0)}%` },
                  { label: 'Orientation', value: rotated ? 'Landscape' : 'Portrait' },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between text-xs">
                    <span className="text-[#64748b]">{label}</span>
                    <span className="text-[#00d4ff] font-mono">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-2">
              Preview — {device.name} ({w}×{h})
            </label>
            <div className="preview-box rounded-xl border border-[#1e2d50] overflow-hidden flex items-start justify-center p-4" style={{ minHeight: MAX_H + 32 }}>
              <div
                style={{
                  width: w * scale,
                  height: h * scale,
                  transform: `scale(1)`,
                  transformOrigin: 'top left',
                  overflow: 'hidden',
                  border: '2px solid #1e2d50',
                  borderRadius: device.category === 'mobile' ? 16 : 8,
                  boxShadow: '0 0 40px rgba(0,0,0,0.5)',
                }}
              >
                <iframe
                  src={url}
                  style={{
                    width: w,
                    height: h,
                    transform: `scale(${scale})`,
                    transformOrigin: 'top left',
                    border: 'none',
                    display: 'block',
                  }}
                  title={`Preview - ${device.name}`}
                  sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
