import { useState } from 'react';
import { Map, Plus, Trash2 } from 'lucide-react';
import ToolLayout from '../components/ToolLayout';
import ExportButton from '../components/ExportButton';

interface SitemapUrl {
  id: number;
  loc: string;
  lastmod: string;
  changefreq: string;
  priority: string;
}

let urlId = 1;
function newUrl(base = ''): SitemapUrl {
  return {
    id: urlId++, loc: base,
    lastmod: new Date().toISOString().split('T')[0],
    changefreq: 'monthly', priority: '0.8',
  };
}

const FREQS = ['always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never'];
const PRIORITIES = ['1.0', '0.9', '0.8', '0.7', '0.6', '0.5', '0.4', '0.3', '0.2', '0.1'];

export default function SitemapGenerator() {
  const [baseUrl, setBaseUrl] = useState('https://example.com');
  const [urls, setUrls] = useState<SitemapUrl[]>([
    { ...newUrl('https://example.com/'), changefreq: 'daily', priority: '1.0', lastmod: new Date().toISOString().split('T')[0] },
    { ...newUrl('https://example.com/about'), changefreq: 'monthly', priority: '0.8', lastmod: new Date().toISOString().split('T')[0] },
    { ...newUrl('https://example.com/blog'), changefreq: 'weekly', priority: '0.9', lastmod: new Date().toISOString().split('T')[0] },
    { ...newUrl('https://example.com/contact'), changefreq: 'yearly', priority: '0.5', lastmod: new Date().toISOString().split('T')[0] },
  ]);

  const update = (id: number, k: keyof SitemapUrl, v: string) =>
    setUrls(u => u.map(url => url.id === id ? { ...url, [k]: v } : url));

  const addUrl = () => setUrls(u => [...u, newUrl(baseUrl + '/')]);
  const removeUrl = (id: number) => setUrls(u => u.filter(url => url.id !== id));

  const bulkAdd = (text: string) => {
    const paths = text.split('\n').map(l => l.trim()).filter(Boolean);
    const newUrls = paths.map(p => ({
      ...newUrl(p.startsWith('http') ? p : `${baseUrl}${p.startsWith('/') ? '' : '/'}${p}`),
    }));
    setUrls(u => [...u, ...newUrls]);
  };

  const generateXml = (): string => {
    const urlEntries = urls.map(u => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${u.lastmod}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join('\n');
    return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${urlEntries}
</urlset>`;
  };

  const output = generateXml();

  const [showBulk, setShowBulk] = useState(false);
  const [bulkText, setBulkText] = useState('');

  return (
    <ToolLayout
      title="Sitemap Generator"
      description="Generate XML sitemaps for better search engine indexing"
      icon={<Map size={20} />}
      badge="XML"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block mb-1">Base URL</label>
            <input value={baseUrl} onChange={e => setBaseUrl(e.target.value.replace(/\/$/, ''))}
              className="input-field w-full px-3 py-2 rounded-xl text-sm" placeholder="https://example.com" />
          </div>

          <div className="flex items-center justify-between">
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">URLs ({urls.length})</label>
            <div className="flex gap-2">
              <button onClick={() => setShowBulk(v => !v)}
                className="text-xs text-[#7c3aed] hover:text-white transition-colors">Bulk Add</button>
              <button onClick={addUrl} className="text-xs text-[#00d4ff] hover:text-white transition-colors flex items-center gap-1">
                <Plus size={12} /> Add URL
              </button>
            </div>
          </div>

          {showBulk && (
            <div className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-4 space-y-2">
              <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider block">Paste URLs (one per line)</label>
              <textarea value={bulkText} onChange={e => setBulkText(e.target.value)}
                className="code-area w-full rounded-lg p-3 text-sm" rows={4}
                placeholder="/about&#10;/blog&#10;/contact&#10;/services" />
              <button onClick={() => { bulkAdd(bulkText); setBulkText(''); setShowBulk(false); }}
                className="btn-primary px-4 py-1.5 rounded-lg text-sm w-full">Add URLs</button>
            </div>
          )}

          <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
            {urls.map((url, i) => (
              <div key={url.id} className="bg-[#060a14] border border-[#1e2d50] rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#00d4ff] font-mono">URL #{i + 1}</span>
                  <button onClick={() => removeUrl(url.id)} className="text-[#ff4466] hover:text-red-300">
                    <Trash2 size={12} />
                  </button>
                </div>
                <input value={url.loc} onChange={e => update(url.id, 'loc', e.target.value)}
                  className="input-field w-full px-3 py-1.5 rounded-lg text-xs font-mono" placeholder="https://example.com/page" />
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-xs text-[#64748b] block mb-0.5">Last Modified</label>
                    <input type="date" value={url.lastmod} onChange={e => update(url.id, 'lastmod', e.target.value)}
                      className="input-field w-full px-2 py-1 rounded-lg text-xs" />
                  </div>
                  <div>
                    <label className="text-xs text-[#64748b] block mb-0.5">Frequency</label>
                    <select value={url.changefreq} onChange={e => update(url.id, 'changefreq', e.target.value)}
                      className="input-field w-full px-2 py-1 rounded-lg text-xs">
                      {FREQS.map(f => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-[#64748b] block mb-0.5">Priority</label>
                    <select value={url.priority} onChange={e => update(url.id, 'priority', e.target.value)}
                      className="input-field w-full px-2 py-1 rounded-lg text-xs">
                      {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <label className="text-xs text-[#64748b] font-mono uppercase tracking-wider">Generated Sitemap XML</label>
            <span className="text-xs text-[#64748b] font-mono">{urls.length} URLs</span>
          </div>
          <textarea readOnly value={output} className="code-area rounded-xl p-4 w-full text-xs flex-1" rows={32} spellCheck={false} />
          <div className="flex justify-end">
            <ExportButton
              formats={[
                { label: 'XML', ext: 'xml', mime: 'application/xml', content: output },
                { label: 'TXT', ext: 'txt', mime: 'text/plain', content: output },
              ]}
              defaultContent={output}
              defaultFilename="sitemap"
              label="Export"
            />
          </div>
        </div>
      </div>
    </ToolLayout>
  );
}
